<?php if(!isset($dashboard)){ ?>
<div class="row">
	<div class="col-sm-12">
		<h4 class="page-title">Master / Employee</h4>
	</div>
</div>
<?php }?>
<div class="row">
	<div class="col-sm-12">
		<div class="card-box">
			<h4 class="header-title"><?php echo isset($title)?$title:"FORM"?></h4>
			<form action="<?php echo isset($action_url)?$action_url:""?>"
				method="POST">
				<div class="row">
					<div class="col-md-6">
						<br>
						<div class="form-group">
							<label for="empcode">Employee Code</label> <input disabled type="text"
								class="form-control" id="empcode" placeholder="Employee Code"
								name="employee_code" required="required"
								value="<?php echo isset($employee_code)?$employee_code:""?>" >
						</div>
						<div class="form-group">
							<label for="empname">Employee Name</label> <input disabled type="text"
								class="form-control" id="empname" placeholder="Employee Name"
								name="employee_name"
								value="<?php echo isset($employee_name)?$employee_name:""?>">
						</div>
						<div class="form-group">
							<label for="empmobile">Mobile Number</label> <input disabled type="text"
								class="form-control" id="empmobile" placeholder="Moble Number"
								name="employee_mobile"
								value="<?php echo isset($employee_mobile)?$employee_mobile:""?>">
						</div>
					</div>
					<!-- end col -->

					<div class="col-md-6">
						<br>
						<div class="form-group">
							<label for="empemail">Email ID</label> <input disabled type="email"
								class="form-control" id="empemail" placeholder="Email address"
								name="employee_email_id"
								value="<?php echo isset($employee_email_id)?$employee_email_id:""?>">
						</div>
						<div class="form-group">
							<label for="empdesignation">Designation</label> <input disabled
								type="text" class="form-control" id="empdesignation"
								name="employee_designation" placeholder="Designation"
								value="<?php echo isset($employee_designation)?$employee_designation:""?>">
						</div>
						<div class="form-group">
							<label for="select2_task"> Discipline</label>
							<input disabled type="text" class="form-control" 
								name="employee_discipline" placeholder="Discipline" value="<?php echo isset($employee_discipline_data)?$employee_discipline_data:""?>">
						</div>
					</div>
					<!-- end col -->
					<div class="col-md-12">
						
					</div>
				</div>
			</form>
		</div>
	</div>
</div>