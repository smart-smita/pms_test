<?php /*
	$htco_project_master['project_code']=$_POST['project_code'];
		$htco_project_master['project_name']=$_POST['project_name'];
		$htco_project_master['project_date']=$_POST['project_date'];
		$htco_project_master['project_client_code']=$_POST['project_client_code'];
		$htco_project_master['project_client_name']=$_POST['project_client_name'];
		$htco_project_master['project_description']=$_POST['project_description'];
*/
?>
		<div id="myModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
                                                    <h4 class="modal-title" id="myModalLabel"></h4>
                                                </div>
                                                <div class="modal-body">
                                                    <h4></h4>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-default waves-effect" data-dismiss="modal">Close</button>
                                                    <button type="button" class="btn btn-custom waves-effect waves-light">Save changes</button>
                                                </div> 
                                            </div><!-- /.modal-content -->
                                        </div><!-- /.modal-dialog -->
                                    </div>
<div class="row">
	<div class="col-sm-12">
		<h4 class="page-title"><?=isset($title)?$title:"Project Master / Task Time Sheet" ?></h4>

<!-- <a href="#custom-modal" class="btn btn-custom waves-effect waves-light m-r-5 m-b-10" data-animation="flash" data-plugin="custommodal" data-overlayspeed="100" data-overlaycolor="#36404a">Flash</a>		<button class="btn btn-custom waves-effect waves-light m-r-5 m-b-10" data-toggle="modal" data-target="#myModal">Standard Modal</button> -->
	</div>
</div>
<div class="row">
	<div class="col-sm-12">
		<div class="card-box">
			<h4 class="header-title">Project Name</h4>
			<div class="row">
				<div class="row">
					<br>
					<div class="col-md-4">
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<select class="form-control select2 project_list project_selected_class" onchange="updateDetails()">
										<option value="0">Select Project Name / Code</option>
										<?php foreach ($project_list as $key => $value) {
											echo "<option value='".$value['project_id']."' data-project-name='".$value['project_name']."' data-project-date='".$value['project_date']."'  data-project-code='".$value['project_code']."'  data-client-name='".$value['project_client_name']."'  data-client-code='".$value['project_client_code']."' data-project-description='".$value['project_description']."' >".$value['project_code']." ".$value['project_name'] ." </option>";
										} ?>
									</select>
								</div>
							</div>
							<div class="col-md-12">
								<div class="form-group">
									<select class="form-control select2 project_task_list_select2">
										<option value="0">Select Discipline Name / Code</option>
									</select>
									<select class="project_task_list" style="display : none;">
										<?php foreach ($discipline_list as $key => $value) {
											echo "<option value='".$value['task_id']."' project_id='".$value['project_id']."'>".$value['task_code']." ".$value['task_name'] ." </option>";
										} ?>
									</select>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-6">
					<div class="col-md-6">
						<b><label id="project_code">Code</label></b><br>
						<label id="project_name">Project Name</label><br>
						<label id="project_date">Date</label>
					</div>
					<div class="col-md-6">
						<b><label id="project_client_code">Code</label></b><br>
						<label id="project_client_name">Client Name</label><br>
					</div>
					</div>
					<div class="col-md-2"><button class="btn btn-purple waves-effect waves-light" onclick="getTaskList()" >Show Details</button> </div>
					<div class="col-md-12">
						<hr>
					</div>
				</div>
				
				<button id="add_task_url_id" fetch-data="html" class="btn btn-default editbtn pull-right">Add Log</button>
				<div class="row task" style='display : none;'> 
					<div class="col-md-12">
						<h4 class="header-title">Task Details </h4>
					</div>
					<div class="col-md-12">
						<table class="table m-0">
							<thead>
								<tr>
									<th>No.</th>
									<th>Task Name</th>
									
									<th>Employee Name</th>
									<th>Task Date </th>
									<th>Work HRs.</th>
									<th>Status</th>
									<th>Action</th>
								</tr>
							</thead>
							<tbody>
							
							</tbody>
						</table>
					</div>				
			</div>
			<!-- end row -->
		</div>
	</div>
</div>

<!-- end col -->
<script>
var get_task_list_url = "<?php echo $task_list_url ?>";
var add_task_url = "<?php echo $add_task_url ?>";
	//$(".discipline").select2("val"); or $(".discipline").select2("data").id;
$('#add_task_url_id').hide();
function getTaskList(){
//	0 : Pending / 1 : Active / 2 : Done / 3 : Canceled / 4 : extended /5 : removed
$('#add_task_url_id').hide();
$('#add_task_url_id').next('.row.task').hide();
if($(".project_list").select2("val")>0 && $(".project_task_list_select2 option:selected").val()>0 <?=isset($isDiscipline)?"|| true":""?>){
 $.ajax({url: get_task_list_url,
 	data:{ project_id : $(".project_list").select2("val") , discipline_id : $(".project_task_list_select2 option:selected").val()},
 	method:"POST",
 	dataType: "JSON",
  success: function(result){
  	$("tbody tr").remove();
	//$('#add_task_url_id').next('.row.task').find("tbody").append("<tr></tr>")
  	if(result.code==0){
		$('#add_task_url_id').show();
		$('#add_task_url_id').next('.row.task').show();
		if(<?=!isset($isDiscipline)?" true":"false"?>){
		$('#add_task_url_id').attr('project_id',result.project_id);
		$('#add_task_url_id').attr('discipline_id',result.discipline_id);
		}else{
			$('#add_task_url_id').hide();
		}
		if(result.task_list.length>0){
			var return_data_html = '';
			$.each( result.task_list, function( key, value ) {
				var action = '<?=!isset($isDiscipline)?'<button class="btn btn-primary editbtn" fetch-data="html" time_log_id="\'+value.time_log_id+\'"><i class="fa fa-edit"></i></button>':'<button id="add_task_url_id-\'+value.time_log_id+\'" fetch-data="html" class="btn btn-default viewdiswisebtn" project_id="\'+result.project_id+\'" discipline_id="\'+value.discipline_id+\'"><i class="fa fa-eye"></i></button> <button title="Add Log" id="add_task_url_id-\'+value.time_log_id+\'" fetch-data="html" class="btn btn-default editbtn" project_id="\'+result.project_id+\'" discipline_id="\'+value.discipline_id+\'" task_id="\'+value.task_id+\'"><i class="fa fa-calendar-plus-o"></i></button>'?>';
				var status = "";
					if(value.time_log_status=="0"){
						status = '<button class="btn-warning">Pending</button>';
					}else if(value.time_log_status=="1"){
						status = '<button class="btn-primary">Done</button>';
					}else if(value.time_log_status=="2"){
						status = '<button class="btn-success">Deactive</button>';
					}else if(value.time_log_status=="3"){
						status = '<button class="btn-danger">Canceled</button>';
					}else if(value.time_log_status=="4"){
						status = '<button class="btn-info">Extended</button>';
					}else if(value.time_log_status=="5"){
						status = '<button class="btn-danger">Removed</button>';
					}
					if(status==''){
						status = '<button class="btn-warning">Pending</button>';
					}
				return_data_html = return_data_html+"<tr><td>"+(key+1)+"</td><td>"+value.task_description+
				"</td> <td>"+value.employee_name+"</td><td>"+value.task_date+"</td><td>"+value.task_hrs+"</td><td>"+status+"</td><td>"+action+"</td></tr>";
			}); 
			$("table tbody").append(return_data_html);
		}
		applayEditClick();
	}else{
		alert(result.msg);
	}
}
}).fail(function() {
	alert( "error" );
});
}else{
	alert("Select Project and Discipline");
}
}
function applayEditClick(){
$( ".editbtn" ).unbind( "click");
$('.editbtn').click(function () {
	$('#myModal').modal('hide');
	$('#myModal').find('.modal-header').remove();	
	$(this).attr('data-target','#myModal');
//	console.log(typeof $(this).attr('time_log_id'));
//	console.log(typeof $(this).attr('project_id'));
//	console.log(typeof $(this).attr('discipline_id'));
	var url  = add_task_url;
	if(typeof $(this).attr('time_log_id')=== 'string'){
		url = add_task_url+'/'+$(this).attr('time_log_id');
	}else if(typeof $(this).attr('project_id')=== 'string' && typeof $(this).attr('discipline_id')=== 'string' && typeof $(this).attr('task_id')!== 'string'){
		url = add_task_url+'/'+$(this).attr('project_id')+'/'+$(this).attr('discipline_id');
	}else if(typeof $(this).attr('project_id')=== 'string' && typeof $(this).attr('discipline_id')=== 'string' && typeof $(this).attr('task_id')=== 'string'){
		url = add_task_url+'/'+$(this).attr('project_id')+'/'+$(this).attr('discipline_id')+'/'+$(this).attr('task_id');
	}
//	if($(this).attr('time_log_id')!=='undefined'){
//		$('#myModal').find('.modal-body').append('<input type="hidden" name="time_log_id" value="'+$(this).attr('time_log_id')+'">');
//	}
	$(this).attr('form-data-url',url);
	ajaxLoader(this,$(this),$('#myModal').find('.modal-body'));
	$('#myModal').find('.modal-dialog').css('width','600px');
	$('#myModal').find('.modal-footer').children().not('[data-dismiss="modal"]').show();
	$('#myModal').find('.modal-footer').children().not('[data-dismiss="modal"]').attr('onclick','btn_model_save_change(this)');
	loadModal(this);
});
$( ".viewdiswisebtn" ).unbind( "click");
$('.viewdiswisebtn').click(function () {
	$('#myModal').modal('hide');
	$('#myModal').find('.modal-header').remove();	
	$(this).attr('data-target','#myModal');
//	console.log(typeof $(this).attr('time_log_id'));
//	console.log(typeof $(this).attr('project_id'));
//	console.log(typeof $(this).attr('discipline_id'));
	var url  = add_task_url;
	if(typeof $(this).attr('project_id')=== 'string' && typeof $(this).attr('discipline_id')=== 'string' && typeof $(this).attr('task_id')!== 'string'){
		url = add_task_url+'/modal_view/'+$(this).attr('project_id')+'/'+$(this).attr('discipline_id');
	}
	$(this).attr('form-data-url',url);
	ajaxLoader(this,$(this),$('#myModal').find('.modal-body'));
	$('#myModal').find('.modal-dialog').css('width','80%');
	$('#myModal').find('.modal-footer').children().not('[data-dismiss="modal"]').hide();
	loadModal(this);
});
}
function updateDetails(){
	//$(selected).attr("value")
		var selected =  $(".project_list option:selected");
			$('#project_name').html( $(selected).attr('data-project-name'));
			$('#project_date').html( $(selected).attr('data-project-date'));
			$('#project_code').html( $(selected).attr('data-project-code'));
			$('#project_client_name').html( $(selected).attr('data-client-name'));
			$('#project_client_code').html( $(selected).attr('data-client-code'));
			$("tbody tr").remove();
		$("select.select2.project_task_list_select2").html($('.project_task_list').find('[project_id='+$('select.project_list option:selected').val()+']').clone());
		$("select.select2.project_task_list_select2").prepend('<option value="0" selected>Select Discipline Name / Code</option>');
}

     
window.onload=function(){
	jQuery('.project_date').datepicker();	
	jQuery('.date-range').datepicker({
                toggleActive: true
            });
}
</script>