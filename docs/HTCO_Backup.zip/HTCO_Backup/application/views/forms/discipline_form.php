<div class="row">
	<div class="col-sm-12">
		<h4 class="page-title">Master / <?=$title?></h4>
	</div>
</div>
<form action ="<?php echo isset($action)?$action:"./"?>" method=post>
<div class="row">
	<div class="col-sm-6">
		<div class="card-box">
			<h4 class="header-title">Discipline Form</h4>
			<div class="row">
				<br>
				<div class="col-md-12">
					<div class="form-group">
						<label for="projectcode">Discipline Code</label> 
						<input type="text" name="class_code"
							class="form-control" id="class_code" placeholder="Discipline Code" value="<?=isset($class_code)?$class_code:""?>">
					</div>
					<div class="form-group">
						<label for="projectname">Discipline Name</label> 
						<input type="text" name="discipline_name"
							class="form-control" id="discipline_name" placeholder="Discipline Name" value="<?=isset($discipline_name)?$discipline_name:""?>">
					</div>
					<div class="form-group">
						<label for="project_address">Discipline Description</label> 
						<input type="text"  name="discipline_description"
							class="form-control" id="discipline_description" placeholder="Discipline Description" value="<?=isset($discipline_description)?$discipline_description:""?>">
					</div>
				</div>
				<div class="col-md-6"></div>
				<div class="col-md-12">
					<button type="submit"
						class="btn btn-purple waves-effect waves-light"
						style="margin-top: 15px; float: right;" onclick="">Submit</button>
				</div>
			</div>
		</div>
	</div>

</div>
</form>
