<div class="row">
	<div class="col-sm-12">
		<h4 class="page-title">Master / Add Project</h4>
	</div>
</div>
<form action ="<?php echo isset($action)?$action:"./"?>" >
<div class="row">
	<div class="col-sm-6">
		<div class="card-box">
			<h4 class="header-title">Project Form</h4>
			<div class="row">
				<br>
				<div class="col-md-12">
					<div class="form-group">
						<label for="projectcode">Project Code</label> 
						<input type="text" name="project_code"
							class="form-control" id="projectcode" placeholder="Project Code" value="<?=isset($project_code)?$project_code:""?>">
					</div>
					<div class="form-group">
						<label for="projectname">Project Name</label> 
						<input type="text" name="project_name"
							class="form-control" id="projectname" placeholder="Project Name" value="<?=isset($project_name)?$project_name:""?>">
					</div>
					<div class="form-group">
						<label for="project_address">Project Address</label> 
						<input type="text" readonly name="project_address"
							class="form-control" id="project_address" placeholder="Project Address" value="<?=isset($project_address)?$project_address:""?>">
					</div>
					<div class="">
						<input type="hidden" name="project_lat"
							class="" id="project_lat" placeholder="project_lat" value="<?=isset($project_lat)?$project_lat:""?>">
					</div>
					<div class="">
						<input type="hidden" name="project_lng"
							class="" id="project_lng" placeholder="project_lng" value="<?=isset($project_lng)?$project_lng:""?>">
					</div>
					<div class="form-group">
						<label for="project_radious">Project Radius</label> <input type="text" name="project_radious"
							class="form-control" id="project_radious" placeholder="project_radious" value="<?=isset($project_radious)?$project_radious:""?>">
					</div>
					<div class="form-group">
						<label for="clientcode">Project Date</label> <input type="text" name="project_date"
							class="form-control" id="project_date" placeholder="Date" value="<?=isset($project_date)?$project_date:""?>">
					</div>
					<div class="form-group">
						<label for="clientcode">Client Code</label> <input type="text" name="project_client_code"
							class="form-control" id="clientcode" placeholder="Client Code" value="<?=isset($project_client_code)?$project_client_code:""?>">
					</div>
					<div class="form-group">
						<label for="clientname">Client Name</label> <input type="text" name="project_client_name"
							class="form-control" id="clientname" placeholder="Client Name" value="<?=isset($project_client_name)?$project_client_name:""?>">
					</div>
					<div class="m-t-20">
						<textarea id="textarea" class="form-control" maxlength="225" name="project_description"
							rows="3" placeholder="Note"><?=isset($project_description)?$project_description:""?></textarea>
					</div>
				</div>
				<div class="col-md-6"></div>
				<div class="col-md-12">
					<button type="submit"
						class="btn btn-purple waves-effect waves-light"
						style="margin-top: 15px; float: right;" onclick="event.preventDefault(); ajaxLoader(this,$(this).closest('form'));">Submit</button>
				</div>
			</div>
		</div>
	</div>
<div class='col-sm-6'>

	<div class="card-box">
			<h4 class="header-title">Project Location</h4>
			<p>Drag project location / search project location</p>
			
			<div id='polymap' style="height : 400px;"></div>
	</div>
</div>
	<!-- end col -->
<?php if(!isset($discipline_data)){ ?>
	<div class="col-sm-6">
		<div class="card-box">
			<h4 class="header-title">Allocate Disciplines</h4>
			<div class="row">
				<br>
				<div class="col-md-12">
						<div class="form-group">
							<label for="projectcode">Discipline Name</label> <select  
								class="form-control select2 discipline">
								<option value="0">Select Discipline Name / Code</option>
								<?php foreach ($discipline as $key => $value) { ?>

								<option value="<?php echo $value['id'] ?>"><?php echo $value['class_code']." ".$value['discipline_name'];  ?></option>
								<?php } ?>  
							</select>
						</div>
						<div class="form-group">
						    <label class="control-label">Date Range</label>
						    <div class="">
						        <div class="input-daterange input-group" id="date-range">
						            <input  type="text" class="form-control start_date"  />
						            <span class="input-group-addon bg-primary b-0 text-white">to</span>
						            <input type="text" class="form-control end_date"  />
						        </div>
						    </div>
						</div>
							<div class="form-group ">
								<label for="totalhrs">Total Hours</label> 
								<input type="number" 
									class="form-control hrs" id="totalhrs" placeholder="Total Hours">
							</div>
						<button type="button"
							class="btn btn-purple waves-effect waves-light"
							onclick="addTask()" style="float: right;">Add Discipline</button>
					<div class="col-md-12">
						<hr>
					</div>
					<div class="col-md-12">
						<table class="table m-0" id="addTaskID">
							<thead>
								<tr>
									<th>No.</th>
									<th>Discipline Name</th>
									<th>Start Date</th>
									<th>End Date</th>
									<th>HRs.</th>
									<th>Action</th>
								</tr>
							</thead>
							<tbody>
							<?php if(isset($discipline_data)) foreach($discipline_data as $key => $val){?>
								<tr> 
									<td><?=$key+1 ?></td> 
									<td>
										<input name="discipline_id[]" value="<?=$val['task_id'] ?>" type="hidden"> 
										<input name="discipline_name[]" value="<?=$val['task_name'] ?>" type="hidden"> 
										<?=$val['task_name'] ?>
									</td>
									<td>
										<input name="discipline_start_date[]" value="<?=$val['plan_start_date'] ?>" type="hidden">
										<?=$val['plan_start_date'] ?>
									</td> 
									<td>
										<input name="discipline_end_date[]" value="<?=$val['plan_end_date'] ?>" type="hidden">
										<?=$val['plan_end_date'] ?>
									</td> 
									<td>
										<input name="discipline_hrs[]" value="<?=$val['plan_hrs'] ?>" type="hidden"><?=$val['plan_hrs'] ?>
									</td> 
									<td>
										<button class="btn btn-icon waves-effect waves-light btn-danger btn-sm" onclick="removeTask(this)">
											<i class="fa fa-remove fa-lg">
											</i>
										</button>
									</td>
								</tr>
							<?php }?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php } ?>
</div>
</form>
<script
	src="https://maps.google.com/maps/api/js?key=AIzaSyDZKSgnIrwIef928cO58eurUMkA8t7rHEo&libraries=places"></script>
<script
	src="<?php echo base_url('/assets/plugins/gmaps/gmaps.min.js')?>"></script>
<script type='text/javascript'>
var map;
$(document).ready(function(){
    map = new GMaps({
      el: '#polymap',
      lat: "<?=isset($project_lat)&&$project_lat!=''?$project_lat:"18.6390451"?>",
      lng: "<?=isset($project_lng)&&$project_lng!=''?$project_lng:"73.7917203"?>",
    });




	var marker = map.addMarker({
		id : 1,
		lat : '<?=isset($project_lat)&&$project_lat!=''?$project_lat:"18.6390451"?>',
		lng : '<?=isset($project_lng)&&$project_lng!=''?$project_lng:"73.7917203"?>',
		animation : google.maps.Animation.DROP,
        dragend : function(e) {
           	map.markers[0].setPosition(new google.maps.LatLng(map.markers[0].getPosition().lat(),map.markers[0].getPosition().lng()));
			map.setCenter(map.markers[0].getPosition().lat(),map.markers[0].getPosition().lng());
			get_Location_Address(map.markers[0].getPosition().lat(),map.markers[0].getPosition().lng());
			//project_lat
			//project_lng
			//project_address
		},
		draggable : true,
		infoWindow : {
			content : 'Project Location'
		},
		title : ''
	});
		var circle = map.drawCircle({
		  radius: Number($('#project_radious').val()),    // 10 miles in metres
		  fillColor: '#AA0000'
		});
		circle.bindTo('center', map.markers[0], 'position');
		$('#project_radious').change(function(){
			circle.setMap(null);
			circle = map.drawCircle({
				  radius: Number($('#project_radious').val()),    // 10 miles in metres
				  fillColor: '#AA0000'
			});
			circle.bindTo('center', map.markers[0], 'position');
		});
  });
  	function get_Location_Address(lat,lng){
		$.ajax({
			url : 'http://maps.googleapis.com/maps/api/geocode/json?latlng='+lat+','+lng+'&sensor=false',
			data : { 
				latt : lat, 
				lngg : lng 
				},
			type : 'POST',
			beforeSend : function() {
			},
			success : function(result) {
				var longname="";
				if(result.status == "OK"){
			//		console.log(result.results[0].address_components);     //////////////////////////
						for(var i=0;i<(result.results[0].address_components).length;i++){
							//var f1 = append_data(result.results[0].address_components[i]);
							//if(f1 == 2){
								if( i<(result.results[0].address_components).length-1){
									longname += result.results[0].address_components[i].long_name;
									longname += ", ";
								}else{
									longname += result.results[0].address_components[i].long_name;
								}
							//}
						}
						$('#project_address').val(longname);
						$('#project_lat').val(lat);
						$('#project_lng').val(lng);
			}
			return true;
			},
			error : function() {
			console.log('Some error occured, Please RETRY !!!');
					return false;
				}
			}).complete(function() {
		});
	}

function addTask(){
//	$(".discipline") 
//$(".discipline").select2("val"); or $(".discipline").select2("data").id;
//$(".discipline").select2("data").text;
//	$(".end_date").val()
//	$(".start_date").val()
//	$(".hrs").val()
if($(".discipline").select2("data").id!="0"){
	if($(".start_date").val() != "" && $(".end_date").val() != ""){
		if($(".hrs").val()!=""){
	var rw = '<tr> <td>'+($('#addTaskID').find('tbody tr').length+1)+'</td> <td><input name="discipline_id[]" value="'+$(".discipline").select2("data").id+'" type="hidden"> <input name="discipline_name[]" value="'+$(".discipline").select2("data").text+'" type="hidden"> '+$(".discipline").select2("data").text+'</td><td><input name="discipline_start_date[]" value="'+$(".start_date").val()+'" type="hidden">'+$(".start_date").val()+'</td> <td><input name="discipline_end_date[]" value="'+$(".end_date").val()+'" type="hidden">'+$(".end_date").val()+'</td> <td><input name="discipline_hrs[]" value="'+$(".hrs").val()+'" type="hidden">'+$(".hrs").val()+'</td> <td><button class="btn btn-icon waves-effect waves-light btn-danger btn-sm" onclick="removeTask(this)"><i class="fa fa-remove fa-lg"></i></button></td></tr>';
	$('#addTaskID').find('tbody').append(rw);
}else{
//$(".hrs").val() not selected 	
}

}else {
//start_date end_date not enter 
}
}else{
//discipline not select dorp down 
}
}
function removeTask(obj){
 $(obj).parent().parent().remove();
 $('#addTaskID').find('tbody tr').each (function(index,item) {
	$($(item).find("td")[0]).html("<td>"+(index+1)+"</td>");
 });
}
window.onload=function(){
	jQuery('#project_date').datepicker();	
	jQuery('#date-range').datepicker({
                toggleActive: true
            });

}
</script>