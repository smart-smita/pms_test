   <div class="text-center logo-alt-box">
            <a href="#" class="logo" style="font-family: serif;"><span>HTC<span style="color: red">O</span></span></a>
            <h5 class="text-muted m-t-0">Welcome To Project Management Portal</h5>
        </div>

        <div class="wrapper-page">

        	<div class="m-t-30 card-box">

                <div class="text-center">
                    <h4 class="text-uppercase font-bold m-b-0">Sign In</h4>
                </div>
                <div class="panel-body">
                    <form class="form-horizontal m-t-10" method="POST" action="<?php echo $form_action ?>">

						<div class="form-group ">
                            <div class="col-xs-12">
                                <input class="form-control" type="text" name="user" required="" placeholder="Username">
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-xs-12">
                                <input class="form-control" type="password" name="pwd" required="" placeholder="Password">
                            </div>
                        </div>

                        <div class="form-group ">
                            <div class="col-xs-12">
                                <div class="checkbox checkbox-custom">
                                    <input id="checkbox-signup" type="checkbox">
                                    <label for="checkbox-signup">
                                        Remember me
                                    </label>
                                </div>

                            </div>
                        </div>

						<div class="form-group text-center m-t-30">
                            <div class="col-xs-12">
                                <button class="btn btn-custom btn-bordred btn-block waves-effect waves-light text-uppercase" type="submit">Log In</button>
                            </div>
                        </div>

                        <div class="form-group m-t-30 m-b-0">
                            <div class="col-sm-12">
                                <a href="page-recoverpw.html" class="text-muted"><i class="fa fa-lock m-r-5"></i> Forgot your password?</a>
                            </div>
                        </div>
<?php if(isset($msg) && $msg!="") { ?>
                        <div class="alert alert-danger">
                                                <strong>Oops !</strong> <?php echo urldecode($msg); ?>
                                            </div>
                                            <script type="text/javascript">
                                                setTimeout('$(".alert-danger").remove()', 1000);
                                            </script>
                                            <?php } ?>


</form>
</div>
</div>
</div>

    

