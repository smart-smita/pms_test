<div class="row">
	<h4 class="form-modal-title"><?=isset($title)?$title:"TITLE"?></h4>
	<div class="col-md-12">
		<div class="row">
			<div class='col-md-12'>
				<div class="form-group">
					<label>Project Name</label>
						<input class='form-control' value="<?=isset($project_name)?$project_name:""?>" type="text" readonly disabled>
				</div>
				<div class="form-group">
					<label>Discipline Name</label>
						<input class='form-control' value="<?=isset($discipline_name)?$discipline_name:""?>" type="text" readonly disabled>
				</div>
				<?php if(isset($task) && count($task)>0){ ?>
				<div class="form-group">
					<label>Choose Task Name (optional)</label>
					<select name="task_id" class="form-control select2" onchange="">
						<option value="0"></option>
						<?php foreach($task as $key=>$val){?>
						<option value="<?=$val['task_id']?>" <?=(isset($task_id)&&$task_id==$val['task_id'])?"selected":""?>><?=$val['task_description']?></option>
						<?php }?>
					</select>
				</div>
				<?php }elseif(isset($task_description) && isset($time_log_on) && $time_log_on==0){?>
				<div class="form-group">
					<label>Task Name</label>
						<input class='form-control' value="<?=$task_description ?>" type="text" readonly disabled>
				</div>
				<?php }?>
				<div class="form-group">
				<?php if(isset($employee)){?>
					<label>Employee Name</label>
					<select name="employee_id" class="form-control select2" onchange="$(this).next(':input').val($(this).find('option:selected').text())">
					<?php foreach($employee as $key=>$val){?>
						<option value="<?=$val['employee_id']?>" <?=(isset($employee_id)&&$employee_id==$val['employee_id'])?"selected":""?>><?=$val['employee_name']?></option>
					<?php }?>
					</select>
					<input name='employee_name' value="" type='hidden'>
				<?php }else {?>
					<label>Employee Name</label>
						<input class='form-control' value="<?=isset($employee_name)?$employee_name:""?>" type="text" readonly disabled>
				<?php }?>
				</div>
			</div>
			<div class='col-md-6'>
				<div class="form-group">
					<label>Log Date</label>
						<input class='form-control date-range' name='task_date' value="<?=isset($task_date)?date('d/m/Y',strtotime($task_date)):""?>" type="text">
				</div>
			</div>
			<div class='col-md-6'>
				<div class="form-group">
					<label>Work HRs.</label>
					<input class='form-control' name='task_hrs' value="<?=isset($task_hrs)?$task_hrs:""?>" type="text">
				</div>
			</div>
		</div>
</div>
<script>
jQuery('.date-range').datepicker({ toggleActive: true, format : 'dd/mm/yyyy'});
$('.select2').select2('destroy'); 
$('.select2').select2(); 
$('select[name=employee_id]').trigger('change');
</script>