<div class="row">
	<h4 class="form-modal-title"><?=isset($title)?$title:"sed"?></h4>
	<div class="col-md-12">
		<div class="form-group">
			<label>Discipline Name</label>
			<?php if(isset($task_name)){?>
				<input class='form-control' value="<?=isset($task_name)?$task_name:""?>" type="text" readonly disabled>
			<?php }else{?>
			<select name="task_id" class='form-control select2' onchange="$(this).next(':input').val($(this).find('option:selected').text())">
				<option value=0>Select Discipline</option>
				<?php if(isset($discipline)) foreach($discipline as $key => $val){?>
				<option value="<?=$val['id']?>" <?=isset($task_id)&&$task_id==$val['id']?"selected":""?>><?=$val['class_code']." ".$val['discipline_name']?></option>
				<?php }?>
			</select>
			<input name="task_name" value="<?=isset($task_name)?$task_name:""?>" type="hidden">
			<?php }?>
		</div>
		<div class="form-group">
			<label>Plan Start & End Date</label>
			<div class="input-daterange input-group <?=isset($task_name)?"":"date-range" ?>">
				<input <?=isset($task_name)?"readonly disabled":"" ?> type="text" class="form-control start_date" value="<?=isset($plan_start_date)?date('m/d/Y',strtotime($plan_start_date)):"" ?>" name="plan_start_date"/>
				<span class="input-group-addon bg-primary b-0 text-white">to</span>
				<input <?=isset($task_name)?"readonly disabled":"" ?> type="text" class="form-control end_date" name="plan_end_date" value="<?=isset($plan_end_date)?date('m/d/Y',strtotime($plan_end_date)):"" ?>"/>
			</div>
		</div>
		<div class="form-group">
			<label>Plan Hrs.</label>
			<input <?=isset($task_name)?"readonly disabled":"" ?> name="plan_hrs" class="form-control"  value="<?=isset($plan_hrs)?$plan_hrs:"" ?>" type="text">
		</div>
		<div class="form-group">
			<label>Actual Start & End Date</label>
			<div class="input-daterange input-group date-range">
				<input  type="text" class="form-control start_date" name="actual_start_date"  value="<?=isset($actual_start_date)?date('m/d/Y',strtotime($actual_start_date)):"" ?>" />
				<span class="input-group-addon bg-primary b-0 text-white">to</span>
				<input type="text" class="form-control end_date" name="actual_end_date" value="<?=isset($actual_end_date)?date('m/d/Y',strtotime($actual_end_date)):"" ?>" />
			</div>
		</div>
		<div class="form-group">
			<label>Actual Hrs.</label>
			<input name="actual_hrs" class="form-control "  value="<?=isset($actual_hrs)?$actual_hrs:"" ?>" type="text">
		</div>
	</div>
</div>
<script>
jQuery('.date-range').datepicker({ toggleActive: true });
$('.select2').select2('destroy'); 
$('.select2').select2(); 
</script>