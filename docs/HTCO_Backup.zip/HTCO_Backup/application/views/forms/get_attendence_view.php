<div class="row">
	<div class="col-sm-12">
		<h4 class="page-title">Employee Attendence</h4>
	</div>
</div>

<div class="row">
	<div class="col-sm-12">
		<div class="card-box">
			<h4 class="header-title">Employees Name</h4>
			<div class="row">
				<div class="row">
					<br>
					<form action="<?php echo $action ?>" method="post" >
						
					<div class="col-md-4">
						<div class="form-group">
							<label for="projectcode">Employees Name</label> <select  
								class="form-control select2" name="id">
								<option value="0">All Employees </option>
								<?php foreach ($employee as $key => $value) { ?>
								<option value="<?php echo $value['employee_id'] ?>"><?php echo $value['employee_code']." ".$value['employee_name'];  ?></option>
								<?php } ?>  
							</select>
						 </div>
						

						</div>
						<div class="col-md-4">
						<div class="form-group">
							<label for="projectcode">To date</label>
						 <input type="date" name="todate" class="form-control"  required>
						</div>
						</div>
						<div class="col-md-4">
						<div class="form-group">
							<label for="projectcode">From date</label>
						 <input type="date" name="fromdate" class="form-control" required>
						</div></div>
						<div class="col-md-4">
						<div class="form-group">
						<button type="submit"
							class="btn btn-purple waves-effect waves-light" >Show Attendence</button>
						</div></div>
					</form>


					</div>
				</div>
			</div>
		</div>
	</div>
