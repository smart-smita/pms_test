<div class="row">
	<h4 class="form-modal-title"><?=isset($title)?$title:"TITLE"?></h4>
	<div class="col-md-12">
		<div class="form-group">
			<label>Project Name</label>
				<input class='form-control' value="<?=isset($project_name)?$project_name:""?>" type="text" readonly disabled>
		</div>
		<div class="form-group">
			<label>Discipline Name</label>
				<input class='form-control' value="<?=isset($discipline_name)?$discipline_name:""?>" type="text" readonly disabled>
		</div>
		<div class="form-group">
			<label>Employee Name</label>
			<?php if(isset($employee)){?>
			<select name="employee_id" class='form-control select2' onchange="$(this).next(':input').val($(this).find('option:selected').text())">
				<option value=0>Select Employee</option>
				<?php foreach($employee as $key => $val){?>
				<option value="<?=$val['employee_id']?>" <?=isset($employee_id)&&$employee_id==$val['employee_id']?"selected":""?>><?=$val['employee_name']?></option>
				<?php }?>
			</select>
			<input name='employee_name' value="" type='hidden'>
			<?php }?>
		</div>
		<div class="form-group">
			<label>Task Description</label>
				<textarea class="form-control" name="task_description"><?=isset($task_description)?$task_description:""?></textarea>
		</div>
		<div class="row">
			<div class='col-md-6'>
				<div class="form-group">
					<label>Task Start Date</label>
						<input class='form-control date-range' name='task_start_date' value="<?=isset($task_start_datetime)?date('d/m/Y',strtotime($task_start_datetime)):""?>" type="text">
				</div>
			</div>
			<div class='col-md-6'>
				<div class="form-group">
					<label>Start Time</label>
						<input class='form-control time-picker' name='task_start_time' value="<?=isset($task_start_datetime)?date('H:i',strtotime($task_start_datetime)):""?>" type="text">
				</div>
			</div>
			<div class='col-md-6'>
				<div class="form-group">
					<label>Task End Date</label>
						<input class='form-control date-range' name='task_end_date' value="<?=isset($task_end_datetime)?date('d/m/Y',strtotime($task_end_datetime)):""?>" type="text">
				</div>
			</div>
			<div class='col-md-6'>
				<div class="form-group">
					<label>End Time</label>
						<input class='form-control time-picker' name='task_end_time' value="<?=isset($task_end_datetime)?date('H:i',strtotime($task_end_datetime)):""?>" type="text">
				</div>
			</div>
		</div>
		<div class="form-group">
			<label>Work HRs.</label>
				<input class='form-control' name='work_hrs' value="<?=isset($work_hrs)?$work_hrs:""?>" type="text">
		</div>
</div>
<script>
jQuery('.date-range').datepicker({ toggleActive: true, format : 'dd/mm/yyyy'});
jQuery('.time-picker').timepicker({ showMeridian: false });
$('.select2').select2('destroy'); 
$('.select2').select2(); 
$('select[name=employee_id]').trigger('change');
</script>