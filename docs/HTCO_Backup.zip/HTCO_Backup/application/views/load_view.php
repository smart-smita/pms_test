<div class="row">
	<div class="col-sm-12">
		<h4 class="page-title">Master  <?php echo isset($title)?" / ".$title:""?></h4>
	</div>
</div>
<div class="row">
	<div class="col-sm-12">
		<div class="card-box">
			<h4 class="header-title"><?php echo isset($title)?$title:""?></h4>
			<div class="row">
				<div class="col-md-12">
					<?php echo isset($content)?$content:"No Data Found!!!"?>
				</div>
			</div>
		</div>
	</div>
</div>