<div class="row">
	<div class="col-sm-12">
		<h4 class="page-title">Report Master / Attendence</h4>
	</div>
</div>
<div class="row">
	<div class="col-sm-12">
		<div class="card-box">
			<h4 class="header-title">Employee Attendence</h4>
			<div class="row">
				<div class="col-md-12">
					<div class="row">
						<br>

						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	
