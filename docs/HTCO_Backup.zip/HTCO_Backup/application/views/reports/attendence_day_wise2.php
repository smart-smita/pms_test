<div class="row">
	<div class="col-sm-12">
		<h4 class="page-title"><?php echo (isset($title))?$title:"Employee Attendence Day Wise Report";?></h4>
	</div>
</div>



<div class="row">
	<div class="col-sm-12">
		<div class="card-box">
			<h4 class="header-title">Employees Name</h4>
			<div class="row" id="attendence_date">
<h3><?php //echo $value['employee_code']." - ". $value['employee_name']; ?></h3>
<h4>From Date : <?php echo $todate; ?> </h4><h4>To Date : <?php echo $fromdate; ?></h4>
<div class="table-responsive">
				<table class="table table-bordered table-hover  dataTable no-footer">
					<thead>
							<tr>
						<th rowspan="2">Name</th><th rowspan="2">Code</th> 
						<?php 
								for($i=0;$i<=$datecount ; $i++){
								?>
									
	
							<th colspan="2">
								<?php 
									echo "".date("d M",strtotime('+'.$i.' days',strtotime($todate)))."";
								?>     							
							</th>
								 <?php 
 									}// for 

								?>

							</tr>
							<tr>
							<?php 
								for($i=0;$i<=$datecount ; $i++){
								?>
						
							<td style="width: 30px;">In/Out</td>
							<td style="width: 30px;">Hrs</td>
						
														 <?php 
 									}// for 

								?>
</tr>
</thead>
					<tbody>

					<?php
						foreach ($employee as $key => $value) {
							?>
						<tr>
							<th>
								<?php echo $value['employee_name']; ?>
							</th>
							<th>
								<?php echo $value['employee_code']; ?>
							</th>
								
										<?php 
										for($i=0;$i<=$datecount ; $i++){
										?>
									<td > <div class="<?php echo $value['employee_id']."-time-".(date("Y-m-d",strtotime('+'.$i.' days',strtotime($todate))))."";?>"></div> </td>
									<td > <div class="<?php echo $value['employee_id']."-hrs-".(date("Y-m-d",strtotime('+'.$i.' days',strtotime($todate))))."";?>"></div> </td>
										 <?php 
		 									}// for 
		 									?>
							</tr>
					
						<?php
						}// emp loop
					 ?>
					 	</tbody>
					</table>
</div>

			</div>
		</div>
	</div>
</div>
		<td>
		</td>
		<td>
		</td>

<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.3.5/jspdf.debug.js" integrity="sha384-CchuzHs077vGtfhGYl9Qtc7Vx64rXBXdIAZIPbItbNyWIRTdG0oYAqki3Ry13Yzu" crossorigin="anonymous"></script> -->
<script type="text/javascript">
// var doc = new jsPDF();          
// var elementHandler = {
//   '#ignorePDF': function (element, renderer) {
//     return true;
//   }
// };

// var source = window.document.getElementById("attendence_date");
// doc.fromHTML( source, 0, 0, {
//          'width': 522, // max width of content on PDF
//          'elementHandlers': elementHandler
//        }, function(bla) {   doc.save('saveInCallback.pdf');
//       });

//doc.output("dataurlnewwindow");
	<?php
		$hrs = null;

				for($i=0;$i<count($datavalues) ; $i++){
					//echo '$(".'.$datavalues[$i]['employee_id'].'-'.(date("Y-m-d",strtotime($datavalues[$i]['attendence_date']))).'").append("<table class=\"table table-bordered table-hover  dataTable no-footer\" ><tr></tr></table>");';
				//foreach ($attendencerow as $key1 => $value1) {					
					//echo '$(".'.$datavalues[$i]['employee_id'].'-'.(date("Y-m-d",strtotime($datavalues[$i]['attendence_date']))).' table tr:last").append("<td>'.$datavalues[$i]['intime'].'-'.$datavalues[$i]['outtime'].'</td><td></td>");';
					echo '$(".'.$datavalues[$i]['employee_id'].'-hrs-'.(date("Y-m-d",strtotime($datavalues[$i]['attendence_date']))).'").append("<br>'.$datavalues[$i]['hrs'].'<br>");';

					echo '$(".'.$datavalues[$i]['employee_id'].'-time-'.(date("Y-m-d",strtotime($datavalues[$i]['attendence_date']))).'").append("<br><button type=\"button\" class=\"btn btn-a\" data-toggle=\"tooltip\" data-placement=\"left\" title=\"\" data-original-title=\"'.$datavalues[$i]['in_address'].'\">'.$datavalues[$i]['intime'].'</button> <button type=\"button\" class=\"btn btn-a\" data-toggle=\"tooltip\" data-placement=\"left\" title=\"\" data-original-title=\"'.$datavalues[$i]['in_address'].'\">'.$datavalues[$i]['outtime'].'</button> -");';
				//}// date
	//			echo '$(".'.$datavalues[$i]['employee_id'].'-'.(date("Y-m-d",strtotime($datavalues[$i]['attendence_date']))).' table").append("<tr></tr>");';
			}
		?>


		

</script>