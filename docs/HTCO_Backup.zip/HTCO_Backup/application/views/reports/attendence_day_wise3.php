<div class="row">
	<div class="col-sm-12">
		<h4 class="page-title"><?php echo (isset($title))?$title:"Employee Attendence Day Wise Report";?></h4>
	</div>
</div>



<div class="row">
	<div class="col-sm-12">
		<div class="card-box">
			<div class="row" id="attendence_date">
<h4>From Date : <?php echo $todate; ?> </h4><h4>To Date : <?php echo $fromdate; ?></h4>
<div class="table-responsive">
				<table class="table table-bordered table-hover  dataTable no-footer">
						<thead>
							<tr>
						<th rowspan="2">Name</th>
						<th rowspan="2">Code</th> 
						<?php 
								for($i=0;$i<=$datecount ; $i++){
								?>
							<th colspan="<?=count($attendencerow)?>">
								<?php 
									echo "".date("d M",strtotime('+'.$i.' days',strtotime($todate)))."";
								?>     							
							</th>
								 <?php 
 									}// for 

								?>
							</tr>
							
						</thead>


						<tbody>
								<?php
									foreach ($employee as $key => $value) {
								?>
 
						<tr>
							<th>
								<?php echo $value['employee_name']; ?>
							</th>
							<th>
								<?php echo $value['employee_code']; ?>
							</th>

								<?php 
								for($i=0;$i<=$datecount ; $i++){
								?>
									<?php foreach ($attendencerow as $key1 => $value1) {
									?>

									<td class="<?php echo $value['employee_id']."-".$key1."-".(date("Y-m-d",strtotime('+'.$i.' days',strtotime($todate))))."";?>"> - </td>
								 	<?php 
	 									}// attendencerow 
									?>
								
							<?php }//$date ?>
						</tr>
							<?php }//$emp ?>

						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>

<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.3.5/jspdf.debug.js" integrity="sha384-CchuzHs077vGtfhGYl9Qtc7Vx64rXBXdIAZIPbItbNyWIRTdG0oYAqki3Ry13Yzu" crossorigin="anonymous"></script> -->
<script type="text/javascript">
// var doc = new jsPDF();          
// var elementHandler = {
//   '#ignorePDF': function (element, renderer) {
//     return true;
//   }
// };

// var source = window.document.getElementById("attendence_date");
// doc.fromHTML( source, 0, 0, {
//          'width': 522, // max width of content on PDF
//          'elementHandlers': elementHandler
//        }, function(bla) {   doc.save('saveInCallback.pdf');
//       });

//doc.output("dataurlnewwindow");
	<?php
		foreach ($attendencerow as $key1 => $value1) {
				for($i=0;$i<count($datavalues) ; $i++){
					if( $key1=="in_address" && isset($datavalues[$i]['in_task_id']) &&  $datavalues[$i]['in_task_id']=="0"){
					echo '$(".'.$datavalues[$i]['employee_id'].'-'.$key1.'-'.(date("Y-m-d",strtotime($datavalues[$i]['attendence_date']))).'").addClass("info");';
					}else if($key1=="out_address" && isset($datavalues[$i]['out_task_id']) &&  $datavalues[$i]['out_task_id']=="0"){
					echo '$(".'.$datavalues[$i]['employee_id'].'-'.$key1.'-'.(date("Y-m-d",strtotime($datavalues[$i]['attendence_date']))).'").addClass("info");';
					}
					echo '$(".'.$datavalues[$i]['employee_id'].'-'.$key1.'-'.(date("Y-m-d",strtotime($datavalues[$i]['attendence_date']))).'").html("'.$datavalues[$i][$key1].'");';
				}// date
			}//attendencerow
		
		?>

</script>