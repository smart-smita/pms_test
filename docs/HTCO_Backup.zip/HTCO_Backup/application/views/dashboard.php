
<link rel="stylesheet"
	href="<?=base_url()?>/assets/plugins/morris/morris.css">
<script src="<?=base_url()?>/assets/plugins/morris/morris.min.js"></script>
<script src="<?=base_url()?>/assets/plugins/raphael/raphael-min.js"></script>
<div class="row">
	<div class="col-sm-12">
		<ul class="nav nav-pills nav-pills-custom display-xs-none pull-right">
			<!--			<li role="presentation"><a href="#">Today</a></li>
			<li role="presentation" class="active"><a href="#">Yesterday</a></li>
			<li role="presentation"><a href="#">Last Week</a></li>
-->
		</ul>

		<h4 class="page-title">Dashboard</h4>
	</div>

	<div class="col-lg-6">
		<div class="card-box">
			<div class="dropdown pull-right">
				<a href="#" class="dropdown-toggle card-drop" data-toggle="dropdown"
					aria-expanded="false"> <i class="zmdi zmdi-more-vert"></i>
				</a>
				<ul class="dropdown-menu" role="menu">
					<li><a href="<?=base_url(index_page().'ProjectMaster')?>">Open
							Project</a></li>
				</ul>
			</div>

			<h4 class="header-title m-t-0">Project Details</h4>


			<div class="row text-center m-t-30">
				<div class="col-xs-6">
					<h3 data-plugin="counterup"><?=isset($completed_project)&&isset($inactive_project)&&isset($active_project)?$completed_project+$inactive_project+$active_project:"0"?></h3>
					<p class="text-muted">Total Projects</p>
				</div>
				<div class="col-xs-6">
					<h3 data-plugin="counterup"><?=isset($active_project)?$active_project:"0"?></h3>
					<p class="text-muted">Open Projects</p>
				</div>
			</div>

			<div class="text-center m-t-10">
				<div id="donut-project" style="height: 245px;"></div>
			</div>

		</div>
	</div>
	<div class="col-lg-6">
		<div class="row text-center">
								<?=isset($profile)?$profile:""?>
                            </div>
	</div>
	<div class="row">
	<div class="col-lg-12">
	<div class="col-lg-6">
		<div class="card-box">
			<div class="dropdown pull-right">
				<a href="#" class="dropdown-toggle card-drop" data-toggle="dropdown"
					aria-expanded="false"> <i class="zmdi zmdi-more-vert"></i>
				</a>
				<ul class="dropdown-menu" role="menu">
					<li><a href="<?=base_url(index_page().'ProjectMaster')?>">Open
							Project</a></li>
				</ul>
			</div>

			<h4 class="header-title m-t-0">Project Details</h4>
			<div class="row text-center m-t-30">
				
			</div>

			<div class="text-center m-t-10">
				<div id="donut-project" style="height: 245px;">
				<?=$project_abstract; ?>
				</div>
			</div>

		</div>
	</div>
		<div class="col-lg-6">
		<div class="card-box">
			<div class="dropdown pull-right">
				<a href="#" class="dropdown-toggle card-drop" data-toggle="dropdown"
					aria-expanded="false"> <i class="zmdi zmdi-more-vert"></i>
				</a>
				<ul class="dropdown-menu" role="menu">
					<li><a href="<?=base_url(index_page().'ProjectMaster')?>">Open
							Project</a></li>
				</ul>
			</div>

			<h4 class="header-title m-t-0">Project Details</h4>
			<div class="row text-center m-t-30"> 
				<select name='project_id' data-fetch='html' class="form-control" form-data-url="<?=$task_abstract_url ?>" onchange="ajaxLoader(this,$(this).parent(),$(this).parent().next('.text-center'))">
					<option>Select Project Name</option>
					<?php foreach($project_list as $key=>$val){ ?> 
						<option value="<?=$val['project_id'] ?>"><?=$val['project_name']." (".$val['project_code'].")" ?></option>
					<?php }?> 
				</select>
			</div>

			<div class="text-center m-t-10">
			
			</div>
		</div>
	</div>
	</div>
	</div>

</div>
<?php if(isset($timeline) && false) { ?>
<div class="col-lg-12">
	<div class="card-box">
		<h4 class="header-title m-t-0">Project Details</h4>

		<div class="row text-center m-t-30">
                            <?=isset($timeline)?$timeline:""; ?>
                            </div>
	</div>
</div>
<?php } ?>
<?php if(isset($timeline_new) && false) { ?>
<div class="col-lg-12">
	<div class="card-box">
		<h4 class="header-title m-t-0">Project Details</h4>
		<div class="row text-center m-t-30"><?=$timeline_new ?></div>
	</div>
</div>
<?php } ?>
<?php if(isset($bar_status) && false) { ?>
<div class="col-lg-12">
	<div class="card-box">
		<h4 class="header-title m-t-0">Project Details</h4>
		<div class="row text-center m-t-30"><?=$bar_status ?></div>
	</div>
</div>
<?php } ?>

<!-- End Page-Title -->
<!-- Counter Up  -->
<script
	src="<?=base_url()?>/assets/plugins/waypoints/lib/jquery.waypoints.js"></script>
<script
	src="<?=base_url()?>/assets/plugins/counterup/jquery.counterup.min.js"></script>

<script>
Morris.Donut({
  element: 'donut-project',
  data: [
    {label: "In-Active Projects", value: <?=isset($inactive_project)?$inactive_project:"0"?>},
    {label: "Active Projects", value: <?=isset($active_project)?$active_project:"0"?>},
    {label: "Completed Projects", value: <?=isset($completed_project)?$completed_project:"0"?>}
  ]
});

</script>
