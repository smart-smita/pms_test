<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

<script type="text/javascript">
  google.charts.load("current", {packages:["timeline"]});
  google.charts.setOnLoadCallback(drawChart);
  function drawChart() {

    var container = document.getElementById('example3.1');
    var chart = new google.visualization.Timeline(container);
    var dataTable = new google.visualization.DataTable();

    <?=isset($Column)?$Column:""?>
    dataTable.addRows([
     <?=isset($value)?$value:""?>
    ]);
    chart.draw(dataTable);
  }
</script>

<div id="example3.1" style="height: 200px;"></div>