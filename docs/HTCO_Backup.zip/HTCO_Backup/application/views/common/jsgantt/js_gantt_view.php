<link rel="stylesheet" type="text/css"
	href="<?=base_url('assets/jsGantt') ?>/jsgantt.css" />
<script src="<?=base_url('assets/jsGantt') ?>/jsgantt.js"></script>
<style>
td.gtaskname {
	text-align: left;
}

tr.gname {
	height: 20px;
}
</style>
<div style="position: relative" class="gantt" id="GanttChartDIV"></div>
<script type="text/javascript">
var g = new JSGantt.GanttChart(document.getElementById('GanttChartDIV'), 'week');
if( g.getDivId() != null ) {
 	g.setCaptionType('Complete');
  	g.setDateTaskDisplayFormat('day dd month yyyy');
  	g.setWeekMinorDateDisplayFormat('dd mon');
  	g.setShowTaskInfoLink(1);
  	g.setShowEndWeekDate(1);
//  g.setFormatArr('Day', 'Week', 'Month', 'Quarter');
 	<?php if (isset($table_data)) foreach ($table_data as $key=>$val){?>
	g.AddTaskItem(new JSGantt.TaskItem('<?=$val['id'] ?>', '<?=$val['title'] ?>', '<?=$val['start_date'] ?>', '<?=$val['end_date'] ?>', '<?=$val['class'] ?>', '<?=$val['link'] ?>', <?=$val['is_milestone'] ?>, '<?=$val['resource_name'] ?>', <?=$val['percentage'] ?>, <?=$val['is_group'] ?>, '<?=$val['parent_id'] ?>', <?=$val['open'] ?>, '<?=$val['dependency'] ?>', '<?=$val['caption'] ?>', '<?=$val['note'] ?>', g ));
 	<?php }?>
	g.Draw();
}else{
	alert("Error, unable to create Gantt Chart");
}
	/* 
	g.AddTaskItem(
		new JSGantt.TaskItem(
				1,                	// Unique ID Number
				'HTCO PROJECT 1', 	// Project Name
				'',       			// start date - optional for group    
				'',   			    // end date - optional for group   
				'ggroupblack', 		// css class 
				'', 				//link if any
				0,  				// 1 : milestone ;; 0 : not milestone
				'Brian',  			// Resource Name (employee name)
				0,   				// percent completed
				1,    				// 0 : normal task / 1 : group  / 2 : combined group
				0,    				// parent id => set 0 for top parent
				1, 					//0 : closed / 1 : open
				'', 				// depends on id's
				'', 				//  optional added after task bar
				'Some Notes text', 	// Note if any
				g  					// Gantt chart object
			)
		);
	
	 */
</script>
