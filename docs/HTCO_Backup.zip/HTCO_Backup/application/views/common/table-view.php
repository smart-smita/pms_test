<?php $example2 = (isset($example2))?$example2:"data-table-".rand(); ?>
<link
	href="<?php echo base_url("assets") ?>/plugins/datatables/jquery.dataTables.min.css"
	rel="stylesheet" type="text/css" />
<style>
table.dataTable span.highlight {
	background-color: #FFFF88;
	border-radius: 0.28571429rem;
}

table.dataTable span.column_highlight {
	background-color: #ffcc99;
	border-radius: 0.28571429rem;
}
</style>
<div class="form-panel">
	<section class="content-header">
		<?php if (isset($export_to_excel)) echo $export_to_excel?>
	<div class="row">
			<section class="connectedSortable ui-sortable">
				<div class="box box-primary">
					<div class="box-header">
						<h3 class="box-title"><?php if(isset($title))echo $title; ?></h3>
					</div>
					<div class="box-body table-responsive">
				
				<?php if(isset($display_contents) ){ ?>
					<table id="<?php echo $example2; ?>"
							class="table table-bordered table-hover ">
							<thead>
								<tr>
								<?php foreach ($display_contents as $row) {?>
									<th><?php echo $row ?></th>
								<?php } ?>
							</tr>
							</thead>
							<tbody>
						<?php foreach ($table_data as $row){ ?>
						<tr
									<?php if (isset($row['tr_class']))echo "class=".$row['tr_class']; ?>>
							<?php foreach ($display_contents as $key=>$drow) {?>
									<td> <?php echo $row[$key]; ?></td>
							<?php } ?>
						</tr>
						<?php } ?>
						</tbody>
							<?php if (isset($column_index_total)){?>
							<tfoot>
								<tr>
									<th
										colspan="<?php echo isset($display_contents)?count($display_contents):"1";?>"
										style="text-align: right">Total:</th>
								</tr>
						<?php }?>
								<!--  										  <tr>
								<?php // foreach ($display_contents as $row) {?>
									<th><?php // echo $row ?></th>
								<?php //} ?>
							</tr> 
								-->
							</tfoot>
						</table>
					<?php } ?>
				</div>
				</div>
			</section>
		</div>
	</section>
</div>
<script
	src="<?php echo base_url("assets") ?>/plugins/datatables/jquery.dataTables.min.js"
	type="text/javascript"></script>
<script
	src="<?php echo base_url("assets") ?>/plugins/datatables/dataTables.bootstrap.js"
	type="text/javascript"></script>

<script type="text/javascript">
(function(h,g,b){function e(d,c){d.unhighlight();c.rows({filter:"applied"}).data().length&&d.highlight(b.trim(c.search()).split(/\s+/))}b(g).on("init.dt.dth",function(d,c){if("dt"===d.namespace){var a=new b.fn.dataTable.Api(c),f=b(a.table().body());if(b(a.table().node()).hasClass("searchHighlight")||c.oInit.searchHighlight||b.fn.dataTable.defaults.searchHighlight)a.on("draw.dt.dth column-visibility.dt.dth column-reorder.dt.dth",function(){e(f,a)}).on("destroy",function(){a.off("draw.dt.dth column-visibility.dt.dth column-reorder.dt.dth")}),
a.search()&&e(f,a)}})})(window,document,jQuery);
jQuery.extend({
    highlight: function (node, re, nodeName, className) {
        if (node.nodeType === 3) {
            var match = node.data.match(re);
            if (match) {
                var highlight = document.createElement(nodeName || 'span');
                highlight.className = className || 'highlight';
                var wordNode = node.splitText(match.index);
                wordNode.splitText(match[0].length);
                var wordClone = wordNode.cloneNode(true);
                highlight.appendChild(wordClone);
                wordNode.parentNode.replaceChild(highlight, wordNode);
                return 1; //skip added node in parent
            }
        } else if ((node.nodeType === 1 && node.childNodes) && // only element nodes that have children
                !/(script|style)/i.test(node.tagName) && // ignore script and style nodes
                !(node.tagName === nodeName.toUpperCase() && node.className === className)) { // skip if already highlighted
            for (var i = 0; i < node.childNodes.length; i++) {
                i += jQuery.highlight(node.childNodes[i], re, nodeName, className);
            }
        }
        return 0;
    }
});

jQuery.fn.unhighlight = function (options) {
    var settings = { className: 'highlight', element: 'span' };
    jQuery.extend(settings, options);

    return this.find(settings.element + "." + settings.className).each(function () {
        var parent = this.parentNode;
        parent.replaceChild(this.firstChild, this);
        parent.normalize();
    }).end();
};

jQuery.fn.highlight = function (words, options) {
    var settings = { className: 'highlight', element: 'span', caseSensitive: false, wordsOnly: false };
    jQuery.extend(settings, options);
    
    if (words.constructor === String) {
        words = [words];
    }
    words = jQuery.grep(words, function(word, i){
      return word != '';
    });
    words = jQuery.map(words, function(word, i) {
      return word.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, "\\$&");
    });
    if (words.length == 0) { return this; };

    var flag = settings.caseSensitive ? "" : "i";
    var pattern = "(" + words.join("|") + ")";
    if (settings.wordsOnly) {
        pattern = "\\b" + pattern + "\\b";
    }
    var re = new RegExp(pattern, flag);
    
    return this.each(function () {
        jQuery.highlight(this, re, settings.element, settings.className);
    });
};
</script>
<script type="text/javascript">
var table = $('#<?php echo $example2; ?>').DataTable({
		"paging" : true,
		"searching" : true,
		"lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
		"ordering" : true,
		"fixedHeader": true,
		"searchHighlight": true,
		"info" : true,
		"autoWidth" : false<?php if (isset($column_index_total)){?>,
		"footerCallback": function ( row, data, start, end, display ) {
            var api = this.api(), data;
 
            // Remove the formatting to get integer data for summation
            var intVal = function ( i ) {
                return typeof i === 'string' ?
                    i.replace(/[\$,]/g, '')*1 :
                    typeof i === 'number' ?
                        i : 0;
            };
            // Total over all pages
            total = api
                .column( <?php echo isset($column_index_total)?$column_index_total-1:"1";?> )
                .data()
                .reduce( function (a, b) {
                    return intVal(a) + intVal(b);
                }, 0 );
            // Total over this page
            pageTotal = api
                .column( <?php echo isset($column_index_total)?$column_index_total-1:"1";?>, { page: 'current'} )
                .data()
                .reduce( function (a, b) {
                    return intVal(a) + intVal(b);
                }, 0 );
            // Update footer
            $( api.column( <?php echo isset($column_index_total)?$column_index_total-1:"1";?> ).footer() ).html(
                    'Total : '+pageTotal.toFixed(2) +' ( Grand Total : '+ total.toFixed(2) +' )' //      'Grand Total :  '+ parseFloat(total) +' '
             );
        }
        <?php }?>
   });
	    table.on( 'draw', function () {
	        var body = $( table.table().body() );	 
	        body.unhighlight();
	        body.highlight( table.search() );  
	    } );
</script>
