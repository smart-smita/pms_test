<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description"
	content="A fully featured site, which can be used to CRM">
<meta name="author" content="Unitglo Solutions Pvt. Ltd.">
<link rel="shortcut icon"
	href="<?php echo base_url()?>/assets/images/ethlogo-afterlogin-55x35.png">
<title>HTCO - ETH</title>
<!--Morris Chart CSS -->
<link rel="stylesheet"
	href="<?php echo base_url()?>/assets/plugins/morris/morris.css">
<link
	href="<?php echo base_url()?>/assets/plugins/select2/dist/css/select2.css"
	rel="stylesheet" type="text/css">
<link
	href="<?php echo base_url()?>/assets/plugins/select2/dist/css/select2-bootstrap.css"
	rel="stylesheet" type="text/css">
	<link href="<?php echo base_url()?>/assets/plugins/timepicker/bootstrap-timepicker.min.css" rel="stylesheet">
<link
	href="<?php echo base_url()?>/assets/plugins/toastr/toastr.min.css"
	rel="stylesheet" type="text/css" />

<link href="<?php echo base_url()?>/assets/css/bootstrap.min.css"
	rel="stylesheet" type="text/css" />
<link href="<?php echo base_url()?>/assets/css/menu.css"
	rel="stylesheet" type="text/css" />
<link href="<?php echo base_url()?>/assets/css/core.css"
	rel="stylesheet" type="text/css" />
<link href="<?php echo base_url()?>/assets/css/components.css"
	rel="stylesheet" type="text/css" />
<link href="<?php echo base_url()?>/assets/css/icons.css"
	rel="stylesheet" type="text/css" />
<link href="<?php echo base_url()?>/assets/css/pages.css"
	rel="stylesheet" type="text/css" />
<link href="<?php echo base_url()?>/assets/css/responsive.css"
	rel="stylesheet" type="text/css" />
<link href="<?php echo base_url()?>/assets/css/custome_loading.css"
	rel="stylesheet" type="text/css" />
<!-- HTML5 Shiv and Respond.js IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
        <![endif]-->
<script src="<?php echo base_url()?>/assets/js/modernizr.min.js"></script>
<script src="<?php echo base_url()?>/assets/js/jquery.min.js"></script>
<style type="text/css">
.circle_loading {
	position: fixed;
	top: 0;
	right: 0;
	bottom: 0;
	left: 0;
	z-index: 1000;
	opacity: 0.8;
	background-color: #444242;
}

.circle_loading_div_id, .circle_loading_div_fixed {
	display: none;
}
</style>
</head>
<body class="fixed-left">
	<div class="circle_loading_div_fixed">
		<div style="opacity: 1; z-index: 1001;">
			<div class="circle_inner_loading"
				style="top: 0; width: 30px; margin: 10px auto; height: 30px;"></div>
			<div class="circle_outer_loading"
				style="top: -50px; margin: 0px auto; width: 50px; height: 50px;"></div>
		</div>
	</div>
	<div class="circle_loading_div circle_loading_div_id"
		style="position: fixed; top: 40%; right: 47%; opacity: 1; z-index: 1001;">
		<div class="circle_inner_loading"></div>
		<div class="circle_outer_loading"></div>
	</div>
	<div class="circle_loading circle_loading_div_id"></div>
	<div id="con-close-modal" class="modal fade" tabindex="-1"
		role="dialog" aria-labelledby="myModalLabel" aria-hidden="true"
		style="display: none;">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal"
						aria-hidden="true">x</button>
					<h4 class="modal-title"></h4>
				</div>
				<div class="modal-body"></div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default waves-effect"
						data-dismiss="modal">Close</button>
					<button type="button" onclick="btn_model_save_change(this);"
						class="btn btn-info waves-effect waves-light">Save changes</button>
				</div>
			</div>
		</div>
	</div>
	<!-- Begin page -->
	<div id="wrapper">