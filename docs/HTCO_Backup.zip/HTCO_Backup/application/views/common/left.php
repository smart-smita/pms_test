<!-- ========== Left Sidebar Start ========== -->
<div class="left side-menu">
	<div class="sidebar-inner slimscrollleft">
		<!--- Divider -->
		<div id="sidebar-menu">
			<ul>

				<li class="text-muted menu-title">Navigation 
</li>

				<li class="has_sub"><a href="<?php echo base_url( index_page().'Home')?>"
					class="waves-effect"><i class="zmdi zmdi-view-dashboard"></i> <span>
							Dashboard </span> </a></li>


				<li class="has_sub"><a href="javascript:void(0);"
					class="waves-effect"><i class="zmdi zmdi-layers"></i> <span>
							Project Master </span> <span class="menu-arrow"></span> </a>
					<ul class="list-unstyled">
<!-- 						<li><a
							href="<?php //echo base_url( index_page().'ProjectMaster/addProject')?>">Add
								Project</a></li> -->
						<li><a
							href="<?php echo base_url( index_page().'ProjectMaster')?>">
								Manage Project</a></li>
						<li><a
							href="<?php echo base_url( index_page().'ProjectMaster/addWorkList')?>">Manage
								Project Work</a></li>
						<li><a
							href="<?php echo base_url( index_page().'ProjectMaster/getDisciplineTask')?>">Manage Tasks</a></li>
<li><a
							href="<?php echo base_url( index_page().'ProjectMaster/addWorkLogList')?>">Log Timesheet</a></li>


						<li><a
							href="<?php echo base_url( index_page().'ProjectMaster/getTaskTimeLog')?>">Edit Timesheet</a></li>
					</li>

					</ul></li>
				<!--<li class="has_sub"><a href="javascript:void(0);"
					class="waves-effect"><i class="zmdi zmdi-view-list-alt"></i> <span>
							Task Master </span> <span class="menu-arrow"></span> </a>
					<ul class="list-unstyled">
						<li><a
							href="<?php //echo base_url( index_page().'TaskMaster/getRemainingTasks')?>">Project
								Details</a></li>
						<li><a
							href="<?php //echo base_url(index_page().'TaskMaster/allocateTaskToEmp')?>">Allocate
								To Employee</a></li>
					</ul></li>
					-->
				<li class="has_sub"><a href="javascript:void(0);"
					class="waves-effect"><i class="zmdi zmdi-view-list"></i> <span>
							Report Master </span> <span class="menu-arrow"></span> </a>
					<ul class="list-unstyled">
												<li><a
							href="<?php echo base_url( index_page().'Master/getEmployee')?>">
								Employee Details</a></li>
						<li><a
							href="<?php echo base_url( index_page().'Master/getDiscipline')?>">
								Discipline Details</a></li>

						<!-- <li><a
							href="<?php //echo base_url(index_page().'ReportMaster/getTimeLineDetails')?>">Project
								Timeline Report</a></li> -->
						<li><a
							href="<?php echo base_url(index_page().'ReportMaster/getAttendenceDetails')?>">Attendence
								Report</a></li>
								<li><a
							href="<?php echo base_url(index_page().'ReportMaster/getAttendenceDetails2')?>">Attendence
								Report view 2</a></li>
								<li><a
							href="<?php echo base_url(index_page().'ReportMaster/getAttendenceDetails3')?>">Attendence
								Report view 3</a></li>
<!-- 						<li><a
							href="<?php //echo base_url(index_page().'ReportMaster/getBudgetDetails')?>">Budget
								Report</a></li> -->

					</ul></li>

			</ul>
			<div class="clearfix"></div>
		</div>
		<div class="clearfix"></div>

	</div>
</div>
<!-- Left Sidebar End -->

<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="content-page">
	<!-- Start content -->
	<div class="content">
		<div class="container">