</div>
<!-- container -->
</div>
<!-- content -->
<footer class="footer">
	<?php echo "2017-".(date("Y")+1);?> &copy; <a
        href="http://www.ethdigitalcampus.com/" target="_blank" class="text-muted">Unitglo Solutions Pvt. Ltd. </a>
</footer>
</div>
<!-- ============================================================== -->
<!-- End Right content here -->
<!-- ============================================================== -->
</div>

<!-- END wrapper -->
<script> 
var resizefunc = []; 
</script>
<!-- jQuery  -->

<script src="<?php echo base_url("assets/js/bootstrap.min.js"); ?>"></script>
<script src="<?php echo base_url("assets/js/detect.js"); ?>"></script>
<script src="<?php echo base_url("assets/js/fastclick.js"); ?>"></script>
<script src="<?php echo base_url("assets/js/jquery.slimscroll.js"); ?>"></script>
<script src="<?php echo base_url("assets/js/jquery.blockUI.js"); ?>"></script>
<script src="<?php echo base_url("assets/js/waves.js"); ?>"></script>

<script src="<?php echo base_url("assets/js/wow.min.js"); ?>"></script>
<script src="<?php echo base_url("assets/js/jquery.nicescroll.js"); ?>"></script>
<script src="<?php echo base_url("assets/js/jquery.scrollTo.min.js"); ?>"></script>
<script	src="<?php echo base_url("assets/plugins/select2/dist/js/select2.min.js"); ?>"></script>
<!-- App js -->
<script src="<?php echo base_url("assets/plugins/moment/moment.js"); ?>"></script>
     	<script src="<?php echo base_url("assets/plugins/timepicker/bootstrap-timepicker.min.js"); ?>"></script>
     	<script src="<?php echo base_url("assets/plugins/mjolnic-bootstrap-colorpicker/dist/js/bootstrap-colorpicker.min.js"); ?>"></script>
     	<script src="<?php echo base_url("assets/plugins/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"); ?>"></script>
     	<script src="<?php echo base_url("assets/plugins/bootstrap-daterangepicker/daterangepicker.js"); ?>"></script>
<script
	src="<?php echo base_url("assets/plugins/toastr/toastr.min.js"); ?>"></script>
<script src="<?php echo base_url("assets/js/jquery.core.js"); ?>"></script>
<script src="<?php echo base_url("assets/js/jquery.app.js"); ?>"></script>
<script src="<?php echo base_url("assets/js/custom.min.js"); ?>"></script>
<script type="text/javascript">
$(".select2").select2();
</script>
</body>
</html>