<div class="row">
	<div class="col-sm-12">
		<h4 class="page-title">Master / Project Current Details</h4>
	</div>
</div>
<div class="row">
	<div class="col-sm-12">
		<div class="card-box">
			<h4 class="header-title">Project Curent Status Details</h4>
			<div class="row">
				<div class="col-md-12">
					<div class="row">
						<br>
						<div class="col-md-12">
							<div class="form-group">
								<select class="form-control select2">
									<option>Select Project Name / Code</option>
									<option selected="selected':" value="0">Runway Project [FSE]
										(1111111)</option>
								</select>
							</div>
						</div>
						<div class="col-md-12">
							<hr>
						</div>
					</div>
					<br>
					<div class="col-md-12">
						<div id="bar"
							class="progress progress-striped progress-bar-custom-alt">
							<div class="bar progress-bar progress-bar-custom"
								style="width: 33.3333%;"></div>
						</div>
					</div>
					<div class="col-md-12">
					<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

<script type="text/javascript">
  google.charts.load("current", {packages:["timeline"]});
  google.charts.setOnLoadCallback(drawChart);
  function drawChart() {

    var container = document.getElementById('example5.1');
    var chart = new google.visualization.Timeline(container);
    var dataTable = new google.visualization.DataTable();
    dataTable.addColumn({ type: 'string', id: 'Task' });
    dataTable.addColumn({ type: 'string', id: 'Name' });
    dataTable.addColumn({ type: 'date', id: 'Start' });
    dataTable.addColumn({ type: 'date', id: 'End' });
    dataTable.addRows([
      [ 'Task 1', 'Task ',       new Date(0,0,0,12,0,0),  new Date(0,0,0,13,30,0) ],
      [ 'Task 2', 'Task ',    new Date(0,0,0,14,0,0),  new Date(0,0,0,15,30,0) ],
      [ 'Task 1', 'Task ',        new Date(0,0,0,16,0,0),  new Date(0,0,0,17,30,0) ],
      [ 'P Task 1',   'Task ',    new Date(0,0,0,12,30,0), new Date(0,0,0,14,0,0) ],
      [ 'P Task 1',   'Task ', new Date(0,0,0,14,30,0), new Date(0,0,0,16,0,0) ],
      [ 'P Task 1',   'Task ',     new Date(0,0,0,16,30,0), new Date(0,0,0,18,0,0) ]]);

    var options = {
      timeline: { colorByRowLabel: true }
    };

    chart.draw(dataTable, options);
  }

</script>

<div id="example5.1" style="height: auto;"></div>
					</div>
				</div>
				<div class="col-md-12">
					<button type="submit"
						class="btn btn-purple waves-effect waves-light"
						style="margin-top: 15px;">Submit</button>
				</div>
			</div>
		</div>
	</div>
</div>