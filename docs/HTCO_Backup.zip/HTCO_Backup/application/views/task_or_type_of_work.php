<div class="row">
	<div class="col-sm-12">
		<h4 class="page-title">Master / Add Discipline</h4>
	</div>
</div>
<div class="row">
	<div class="col-sm-12">
		<div class="card-box">
			<h4 class="header-title">Discipline List Form</h4>
			<div class="row">
				<div class="col-md-12">
					<br>
					<div class="form-group">
						<label for="discode">Discipline Code</label> <input type="text"
							class="form-control" id="discode" placeholder="Discipline Code">
					</div>
					<div class="form-group">
						<label for="disname">Discipline Name</label> <input type="text"
							class="form-control" id="disname" placeholder="Discipline Name">
					</div>
				</div>
				<div class="col-md-12">
					<button type="submit"
						class="btn btn-purple waves-effect waves-light"
						style="float: right;">Submit</button>
				</div>
			</div>
			<!-- end row -->

		</div>
	</div>
	<!-- end col -->
</div>