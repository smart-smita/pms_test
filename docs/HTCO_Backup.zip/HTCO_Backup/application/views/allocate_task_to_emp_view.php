<div class="row">
	<div class="col-sm-12">
		<h4 class="page-title">Master / Allocate Tasks</h4>
	</div>
</div>
<div class="row">
	<div class="col-sm-12">
		<div class="card-box">
			<h4 class="header-title">Allocate Task To Employee</h4>
			<div class="row">
				<div class="col-md-12">
					<div class="row">
						<br>
						<div class="col-md-12">
							<div class="form-group">
								<label>Project Name</label> <select class="form-control select2">
									<option>Select Project Name / Code</option>
									<option selected="selected':" value="0">Runway Project [FSE]
										(1111111)</option>
								</select>
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label>Task Name</label> <select class="form-control select2">
									<option>Select Task Name / Code</option>
									<option selected="selected':" value="0">Power</option>
								</select>
							</div>
							<div class="form-group">
								<label>Employee Name</label> <select
									class="form-control select2">
									<option>Select Employee Name / Code</option>
									<option selected="selected':" value="0">Power</option>
								</select>
							</div>
						</div>
						<div class="col-md-6">
							<div class="col-md-12">
								<table class="table m-0">
									<thead>
										<tr>
											<th>No.</th>
											<th>Discipline Name</th>
											<th>Start Date</th>
											<th>End Date</th>
											<th>HRs.</th>
											<th>Status</th>
										</tr>
									</thead>
									<tbody>
										<tr>
											<td>1</td>
											<td>Power</td>
											<td>01-01-2017</td>
											<td>03-01-2017</td>
											<td>4</td>
											<td><button class="btn-success">DONE</button></td>
										</tr>
										<tr>
											<td>2</td>
											<td>Power</td>
											<td>03-01-2017</td>
											<td>04-01-2017</td>
											<td>2</td>
											<td><button class="btn-danger">PENDING</button></td>
										</tr>
										<tr>
											<td>3</td>
											<td>Power</td>
											<td>04-01-2017</td>
											<td>05-01-2017</td>
											<td>5</td>
											<td><button class="btn-danger">PENDING</button></td>
										</tr>
									</tbody>
								</table>
							</div>
						</div>
						<div class="col-md-12">
							<button type="submit"
								class="btn btn-purple waves-effect waves-light"
								style="margin-top: 15px;">Submit</button>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>