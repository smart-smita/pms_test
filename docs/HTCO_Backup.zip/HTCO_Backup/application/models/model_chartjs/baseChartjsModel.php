<?php
if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
#[\AllowDynamicProperties]
class baseChartjsModel extends CI_Model {
	public $colors = array (
			"Red" => array (
					"background_color" => "rgba(255, 99, 132, 1)",
					"border_color" => "rgba(255,99,132,1)" 
			),
			"Blue" => array (
					"background_color" => "rgba(54, 162, 235, 1)",
					"border_color" => "rgba(54, 162, 235, 1)" 
			),
			"Yellow" => array (
					"background_color" => "rgba(255, 206, 86, 1)",
					"border_color" => "rgba(255, 206, 86, 1)" 
			),
			"Green" => array (
					"background_color" => "rgba(75, 192, 192, 1)",
					"border_color" => "rgba(75, 192, 192, 1)" 
			),
			"Purple" => array (
					"background_color" => "rgba(153, 102, 255, 1)",
					"border_color" => "rgba(153, 102, 255, 1)" 
			),
			"Orange" => array (
					"background_color" => "rgba(255, 159, 64, 1)",
					"border_color" => "rgba(255, 159, 64, 1)" 
			),
			"Gray" => array (
					"background_color" => "rgb(201, 203, 207, 1)",
					"border_color" => "rgba(201, 203, 207, 1)" 
			) 
	);
	function __construct() {
		/* Call the Model constructor */
		parent::__construct ();
		$this->load->helper ( 'array' );
	}
	/**
	 * Line Chart Function
	 *
	 * @param string $chartName
	 *        	Name of the chart (line, steppedLine, steppedLine-before, steppedLine-after)
	 * @param string $chartTitle
	 *        	Name of the chart
	 * @param array $ChartValues
	 *        	2D Array with label,value compalsory
	 * @param string $xAxisLabel
	 *        	(optional)
	 *        	Name on X-axis
	 * @param string $yAxisLabel
	 *        	(optional)
	 *        	Name on Y-axis
	 * @param string $beginAtZero
	 *        	(optional)
	 *        	Chart Start Point default auto;
	 */
	function defaultChart($chartName = "line", $chartTitle = "Line Chart", $ChartValues = array(), $xAxisLabel = "Values", $yAxisLabel = "Label", $beginAtZero = false, $operation='width="400" height="250"') {
		$data = null;
		// Line
		$data ['type'] = $chartName;
		$data ['displayXAxis'] = true;
		$data ['displayYAxis'] = true;
		$data ['displayTooltipSeperate'] = false;
		if ($chartName == 'radar' || $chartName == 'doughnut' || $chartName == 'pie' || $chartName == 'polarArea') {
			$data ['displayXAxis'] = false;
			$data ['displayYAxis'] = false;
			$data ['displayTooltipSeperate'] = true;
		}
		if ($chartName == 'scatter') {
			$data ['displayTooltipSeperate'] = true;
		}
		if ($chartName == 'combineLineBar') {
			$data ['type'] = 'bar';
		}
		$data ['steppedLine'] = false;
		$data ['cubicInterpolationLine'] = false;
		$data ['horizontalBar'] = false;
		$data ['horizontalStackedBar'] = false;
		$data ['dottedLine'] = false;
		$data ['groupStackedBar'] = false;
		
		if ($chartName == 'combineStackedLineBar') {
			$data ['type'] = 'bar';
			$data ['horizontalStackedBar'] = true;
			$data ['groupStackedBar'] = true;
			$chartName = 'combineLineBar';
		}
		
		if ($chartName == 'dottedLine') {
			$data ['dottedLine'] = true;
			$data ['type'] = "line";
		} elseif ($chartName == 'steppedLine') {
			$data ['steppedLine'] = true;
			$data ['type'] = "line";
		} elseif ($chartName == 'steppedLineAfter') {
			$data ['steppedLine'] = "after";
			$data ['type'] = "line";
		} elseif ($chartName == 'steppedLineBefore') {
			$data ['steppedLine'] = "before";
			$data ['type'] = "line";
		} elseif ($chartName == 'cubicInterpolationLine') {
			$data ['cubicInterpolationLine'] = true;
			$data ['type'] = "line";
		} elseif ($chartName == 'horizontalBar') {
			$data ['horizontalBar'] = true;
			$data ['type'] = "horizontalBar";
		} elseif ($chartName == 'horizontalStackedBar') {
			$data ['horizontalStackedBar'] = true;
			$data ['type'] = "horizontalBar";
		} elseif ($chartName == 'stackedBar') {
			$data ['horizontalStackedBar'] = true;
			$data ['type'] = "bar";
		} elseif ($chartName == 'groupStackedBar') {
			$data ['horizontalStackedBar'] = true;
			$data ['groupStackedBar'] = true;
			$data ['type'] = "bar";
		} elseif ($chartName == 'horizontalGroupStackedBar') {
			$data ['horizontalStackedBar'] = true;
			$data ['groupStackedBar'] = true;
			$data ['type'] = "horizontalBar";
		}
		// (X,Y) Start Point true for 0 else default
		$data ['beginAtZero'] = $beginAtZero;
		// Chart Title
		$data ['chartTitle'] = $chartTitle;
		// X-Axis Label
		$data ['xAxisLabel'] = $xAxisLabel;
		// Y-Axis Label
		$data ['yAxisLabel'] = $yAxisLabel;
		$data ['chart_attr'] = $operation;
		$data ['chartData'] = null;
		foreach ( $ChartValues as $key => $val ) {
			$data ['dataLabels'] = '';
			$data ['chartData'] [$key] ['dataValues'] = '';
			if (isset ( $val ['stack'] ))
				$data ['chartData'] [$key] ['stack'] = $val ['stack'];
			$data ['chartData'] [$key] ['type'] = "";
			if (isset ( $val ['type'] ) && $chartName == 'combineLineBar')
				$data ['chartData'] [$key] ['type'] = $val ['type'];
			
			$data ['chartData'] [$key] ['backgroundColor'] = array ();
			$data ['chartData'] [$key] ['borderColor'] = array ();
			if (isset ( $val ['interpolation'] ) && $data ['cubicInterpolationLine']) {
				$data ['chartData'] [$key] ['interpolation'] = $val ['interpolation'];
			}
			// Label For The Data Row
			$data ['chartData'] [$key] ['setLabel'] = $val ['title'];
			// True for Fill
			if (isset ( $val ['fill_background'] ))
				$data ['chartData'] [$key] ['fill'] = $val ['fill_background'];
			
			if (isset ( $val ['background_color'] )) {
				$data ['chartData'] [$key] ['backgroundColor'] = '"' . $this->colors [$val ['background_color']] ['background_color'] . '"';
				$data ['chartData'] [$key] ['borderColor'] = '"' . $this->colors [$val ['background_color']] ['border_color'] . '"';
			}
			foreach ( $val ['values'] as $key1 => $val1 ) {
				if ($chartName == "scatter") {
					if ($key1 == 0) {
						$data ['dataLabels'] .= '';
						$data ['chartData'] [$key] ['dataValues'] .= ($data ['cubicInterpolationLine'] && $val1 ['value'] == '' ? 'NaN' : '{ x : ' . $val1 ['value'] . ', y : ' . $val1 ['label'] . '}');
					} else {
						$data ['dataLabels'] .= '';
						$data ['chartData'] [$key] ['dataValues'] .= ($data ['cubicInterpolationLine'] && $val1 ['value'] == '' ? ',NaN' : ', { x : ' . $val1 ['value'] . ', y : ' . $val1 ['label'] . '}');
					}
				} else {
					if ($key1 == 0) {
						$data ['dataLabels'] .= '"' . $val1 ['label'] . '"';
						$data ['chartData'] [$key] ['dataValues'] .= ($data ['cubicInterpolationLine'] && $val1 ['value'] == '' ? 'NaN' : '"' . $val1 ['value'] . '"');
					} else {
						$data ['dataLabels'] .= ', "' . $val1 ['label'] . '"';
						$data ['chartData'] [$key] ['dataValues'] .= ($data ['cubicInterpolationLine'] && $val1 ['value'] == '' ? ',NaN' : ', "' . $val1 ['value'] . '"');
					}
				}
				
				if (is_array ( $data ['chartData'] [$key] ['backgroundColor'] )) {
					if (isset ( $val1 ['background_color'] )) {
						array_push ( $data ['chartData'] [$key] ['backgroundColor'], element ( $val1 ['background_color'], $this->colors )['background_color'] );
						array_push ( $data ['chartData'] [$key] ['borderColor'], element ( $val1 ['background_color'], $this->colors )['border_color'] );
					} else {
						$temp_color = random_element ( $this->colors );
						$data ['chartData'] [$key] ['backgroundColor'] = '"' . $temp_color ['background_color'] . '"';
						$data ['chartData'] [$key] ['borderColor'] = '"' . $temp_color ['border_color'] . '"';
					}
				}
			}
		}
		return $this->load->view ( 'common/default_line_chart', $data, true );
	}
}
?>