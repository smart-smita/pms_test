<?php
require_once APPPATH . 'core/Base_Controller.php';
if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
#[\AllowDynamicProperties]
class TaskMaster extends Base_Controller {
	public function __construct() {
		parent::__construct ();
			if(!isset($_SESSION['employee_code']) || $_SESSION['employee_code'] == ""){
				  redirect(base_url("index.php/Welcome/index/your session has expired please re-login"));
			}

	}
	public function index() {
		$this->view ( "dashboard" );
	}
	public function getRemainingTasks() {
		$this->view ( "get_selected_project_details" );
	}
	public function allocateTaskToEmp($id = null) {
		$this->view ( "allocate_task_to_emp_view" );
	}
}
?>