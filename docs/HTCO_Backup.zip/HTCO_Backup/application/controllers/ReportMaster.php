<?php
require_once APPPATH . 'core/Base_Controller.php';
if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
#[\AllowDynamicProperties]
class ReportMaster extends Base_Controller {
	public function __construct() {
		parent::__construct ();
			if(!isset($_SESSION['employee_code']) || $_SESSION['employee_code'] == ""){
				  redirect(base_url("index.php/Welcome/index/your session has expired please re-login"));
			}

	}
	public function getTimeLineDetails() {		
		$this->view ( "get_selected_project_details" );
	}
	public function getAttendenceDetails() {
		$data['employee'] = $this->Base_Models->GetAllValues("htco_employee_master");
		$data['action'] = base_url(index_page()."ReportMaster/getEmployeeAttendence");
		
		$this->view("forms/get_attendence_view",$data);
//		$this->view ( "get_attendence_view" );
	}
	public function getAttendenceDetails3() {
		$data['employee'] = $this->Base_Models->GetAllValues("htco_employee_master");
		$data['action'] = base_url(index_page()."ReportMaster/getEmployeeAttendence3");
		
		$this->view("forms/get_attendence_view",$data);
//		$this->view ( "get_attendence_view" );
	}
	public function getAttendenceDetails2() {
		$data['employee'] = $this->Base_Models->GetAllValues("htco_employee_master");
		$data['action'] = base_url(index_page()."ReportMaster/getEmployeeAttendence2");
		
		$this->view("forms/get_attendence_view",$data);
//		$this->view ( "get_attendence_view" );
	}
		public function getEmployeeAttendence2($id=null,$todate=null,$fromdate=null){
		if(!isset($id)){
			if(isset($_POST['id'])){
			$id= $_POST['id'];
			$todate=$_POST['todate'];
			$fromdate=$_POST['fromdate'];
			$date1 = new DateTime($todate);
			$date2 = new DateTime($fromdate);
			$interval = $date1->diff($date2);

			$data['datecount'] = $interval->days;
			$data['todate'] = $todate;
			$data['fromdate'] = $fromdate;
			$data ['attendencerow'] = array (
			"inout" => "Time in / out",
			"hrs" => "Hrs",
			"in_out_address" => "Location"
			);
			
			if($id==0){
				$data['employee'] = $this->Base_Models->CustomeQuary("select * from htco_employee_master ORDER BY employee_code ASC");
				$data ['datavalues'] = $this->Base_Models->CustomeQuary ( "SELECT in_task_id,out_task_id,CONCAT(in_latitude,' , ',in_longitude) as in_location , CONCAT(out_latitude,' , ',out_longitude) as out_location, CONCAT(in_address,' , ',out_address) as in_out_address ,in_address,out_address,`attendence_in_time` as intime, `attendence_out_time` as outtime,CONCAT(attendence_in_time ,' , ', attendence_out_time) as attendence_in_out_time, `attendence_date` ,TIMEDIFF(  `attendence_out_time`, `attendence_in_time`)  hrs ,employee_id ,in_address,out_address
				 FROM (`htco_attendence_details`) WHERE   (default_date BETWEEN '". $todate ." 00:00:00' and '".$fromdate." 23:59:59' ) and `employee_id` in (select employee_id from htco_employee_master) order by attendence_date,employee_id ASC");		

				$data ['datavaluesHrs']="select sum(TIMEDIFF(  `attendence_out_time`, `attendence_in_time`)) hrs , attendence_date, employee_id
				FROM (`htco_attendence_details`) WHERE  (default_date BETWEEN '". $todate ." 00:00:00' and '".$fromdate." 23:59:59' ) and `employee_id` in (select employee_id from htco_employee_master) group by attendence_date,employee_id ";
				}else{
				$data['employee'] = $this->Base_Models->GetAllValues("htco_employee_master",array("employee_id"=>$id));
				$data ['datavalues'] = $this->Base_Models->CustomeQuary ( "SELECT in_task_id,out_task_id,CONCAT(in_latitude,' , ',in_longitude) as in_location , CONCAT(out_latitude,' , ',out_longitude) as out_location, CONCAT(in_address,' , ',out_address) as in_out_address ,in_address,out_address,`attendence_in_time` as intime, `attendence_out_time` as outtime,CONCAT(attendence_in_time ,' , ', attendence_out_time) as attendence_in_out_time, `attendence_date` ,TIMEDIFF(  `attendence_out_time`, `attendence_in_time`)  hrs ,employee_id,in_address,out_address
				 FROM (`htco_attendence_details`) WHERE (default_date BETWEEN '". $todate ." 00:00:00' and '".$fromdate." 23:59:59' ) and `employee_id` = ".$id." order by attendence_date,employee_id ASC ");		
				$data ['datavaluesHrs']="select sum(TIMEDIFF(  `attendence_out_time`, `attendence_in_time`)) hrs , attendence_date, employee_id
				FROM  (`htco_attendence_details`) WHERE  (default_date BETWEEN '". $todate ." 00:00:00' and '".$fromdate." 23:59:59' ) and `employee_id` = ".$id." group by attendence_date,employee_id  ";
						
				}
			//	print_r($data ['datavalues']);
			//	exit();

			 // if($id==0){
			 // 		$data['employee'] = $this->Base_Models->GetAllValues("htco_employee_master",array("employee_id"=>$id));
			 // 	$this->Base_Models->CustomeQuary ( "select * from htco_attendence_details ");
			 // }else {

			 // }
						$data ['title'] = "Employee Attendence Day Wise Report";
					//	$data1 ['content'] = $this->load->view ( "", $data, true );
						$this->view ( "reports/attendence_day_wise2", $data );

		}else{
			redirect(base_url(index_page()."ReportMaster/getAttendenceDetails2"));
		}
		}

	}

	public function getEmployeeAttendence($id=null,$todate=null,$fromdate=null){
		if(!isset($id)){
			if(isset($_POST['id'])){
			$id= $_POST['id'];
			$todate=$_POST['todate'];
			$fromdate=$_POST['fromdate'];
			$date1 = new DateTime($todate);
			$date2 = new DateTime($fromdate);
			$interval = $date1->diff($date2);

			$data['datecount'] = $interval->days;
			$data['todate'] = $todate;
			$data['fromdate'] = $fromdate;
			$data ['attendencerow'] = array (
			"intime" => "In",
			"outtime" => "Out",
			"hrs" => "Hrs",
			"in_address" => "In Address",
			"out_address" => "Out Address"
			);
			
			if($id==0){
				$data['employee'] = $this->Base_Models->CustomeQuary("select * from htco_employee_master ORDER BY employee_code ASC");
				$data ['datavalues'] = $this->Base_Models->CustomeQuary ( "SELECT in_task_id,out_task_id,CONCAT(in_latitude,' , ',in_longitude) as in_location , CONCAT(out_latitude,' , ',out_longitude) as out_location,in_address,out_address,min(`attendence_in_time`) as intime, max(`attendence_out_time`) as outtime, `attendence_date` ,TIMEDIFF(  max(`attendence_out_time`), min(`attendence_in_time`) ) hrs ,employee_id
				 FROM (`htco_attendence_details`) WHERE  (default_date BETWEEN '". $todate ." 00:00:00' and '".$fromdate." 23:59:59' ) and `employee_id` in (select employee_id from htco_employee_master) group by attendence_date,employee_id ");		
						
				}else{
				$data['employee'] = $this->Base_Models->GetAllValues("htco_employee_master",array("employee_id"=>$id));
				$data ['datavalues'] = $this->Base_Models->CustomeQuary ( "SELECT in_task_id,out_task_id,CONCAT(in_latitude,' , ',in_longitude) as in_location , CONCAT(out_latitude,' , ',out_longitude) as out_location,in_address,out_address,min(`attendence_in_time`) as intime, max(`attendence_out_time`) as outtime, `attendence_date` ,TIMEDIFF(  max(`attendence_out_time`), min(`attendence_in_time`) ) hrs ,employee_id
				 FROM (`htco_attendence_details`) WHERE  (default_date BETWEEN '". $todate ." 00:00:00' and '".$fromdate." 23:59:59' ) and `employee_id` = ".$id." group by attendence_date,employee_id  ");		
						
				}
						$data ['title'] = "Employee Attendence Day Wise Hrs Report";
					//	$data1 ['content'] = $this->load->view ( "", $data, true );
						$this->view ( "reports/attendence_day_wise", $data );

		}else{
			redirect(base_url(index_page()."ReportMaster/getAttendenceDetails"));
		}
		}

	}



	public function getEmployeeAttendence3($id=null,$todate=null,$fromdate=null){
		if(!isset($id)){
			if(isset($_POST['id'])){
			$id= $_POST['id'];
			$todate=$_POST['todate'];
			$fromdate=$_POST['fromdate'];
			$date1 = new DateTime($todate);
			$date2 = new DateTime($fromdate);
			$interval = $date1->diff($date2);

			$data['datecount'] = $interval->days;
			$data['todate'] = $todate;
			$data['fromdate'] = $fromdate;
			$data ['attendencerow'] = array (
			"hrs" => "Hrs",
			);
			
			if($id==0){
				$data['employee'] = $this->Base_Models->CustomeQuary("select * from htco_employee_master ORDER BY employee_code ASC");
				$data ['datavalues'] = $this->Base_Models->CustomeQuary ( "SELECT in_task_id,out_task_id,CONCAT(in_latitude,' , ',in_longitude) as in_location , CONCAT(out_latitude,' , ',out_longitude) as out_location,in_address,out_address,min(`attendence_in_time`) as intime, max(`attendence_out_time`) as outtime, `attendence_date` ,TIMEDIFF(  max(`attendence_out_time`), min(`attendence_in_time`) ) hrs ,employee_id
				 FROM (`htco_attendence_details`) WHERE  (default_date BETWEEN '". $todate ." 00:00:00' and '".$fromdate." 23:59:59' ) and `employee_id` in (select employee_id from htco_employee_master) group by attendence_date,employee_id ");		
						
				}else{
				$data['employee'] = $this->Base_Models->GetAllValues("htco_employee_master",array("employee_id"=>$id));
				$data ['datavalues'] = $this->Base_Models->CustomeQuary ( "SELECT in_task_id,out_task_id,CONCAT(in_latitude,' , ',in_longitude) as in_location , CONCAT(out_latitude,' , ',out_longitude) as out_location,in_address,out_address,min(`attendence_in_time`) as intime, max(`attendence_out_time`) as outtime, `attendence_date` ,TIMEDIFF(  max(`attendence_out_time`), min(`attendence_in_time`) ) hrs ,employee_id
				 FROM (`htco_attendence_details`) WHERE  (default_date BETWEEN '". $todate ." 00:00:00' and '".$fromdate." 23:59:59' ) and `employee_id` = ".$id." group by attendence_date,employee_id  ");		
						
				}
						$data ['title'] = "Employee Attendence Day Wise Report";
					//	$data1 ['content'] = $this->load->view ( "", $data, true );
						$this->view ( "reports/attendence_day_wise3", $data );

		}else{
			redirect(base_url(index_page()."ReportMaster/getAttendenceDetails3"));
		}
		}

	}

	public function getBudgetDetails() {
		$this->view ( "get_selected_project_details" );
	}
	public function ganttchart(){
			$this->view("reports/graphical/projectWiseGanttchart",$data);
	}
}
?>