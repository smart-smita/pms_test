<?php
require_once APPPATH . 'core/Base_Controller.php';
if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
#[\AllowDynamicProperties]
class Login extends Base_Controller {
	public function __construct() {

		parent::__construct ();
	}
	
	
	public function getMapTaskList(){
		$responce = null;
		$responce['code'] = '2';
		$responce['msg'] = 'Error';
		$responce['data'] = null;
	
		if(isset($_POST['employee_code']) ){

		   
			$tableName = 'htco_project_master';
			$where['project_status'] = '1'; 
			
			$temp = $this->Base_Models->GetAllValues($tableName,$where);
			
			$responce['code'] = '1';
		    $responce['msg'] = 'No Task Found';
			
			if(count($temp)>0){
				$responce['code'] = '0';
		        $responce['msg'] = 'Data Found';
		        $responce['data'] = $temp;
			}else{
				$responce['code'] = '1';
		        $responce['msg'] = 'No Task Found';
			}
			
		}
		
		echo json_encode($responce);
	}
	
	
	public function getTaskList(){
		$responce = null;
		$responce['code'] = '2';
		$responce['msg'] = 'Error';
		
			$where=" ";	

		if(isset($_POST['employee_code'])){
	
			if( isset($_POST['date_start'])){
$where .="attendence_date >= '".date("Y-m-d",strtotime($_POST['date_start']))."' and ";

}
if( isset($_POST['date_end'])){
$where .="attendence_date <= '".date("Y-m-d",strtotime($_POST['date_end']))."' and ";
}

			$pram['employee_id'] = $_POST['employee_code'];
			
			$user = $this->Base_Models->GetAllValues('htco_employee_master',$pram);
			
				if(count($user) > 0 ){
				
				//$temp = $this->Base_Models->GetAllValues ('htco_attendence_details',$pram);
				$tableName = 'htco_attendence_details';
				$where .= 'employee_id = '.$user[0]['employee_id'];
				$orderByName = 'attendence_id';
				$orderBy = 'DESC';
				$query = 'SELECT * FROM '.$tableName.' WHERE '.$where.' ORDER BY '.$orderByName.' '.$orderBy ;
				$temp = $this->Base_Models->CustomeQuary($query);
				if(count($temp) > 0){
					$responce['code'] = '0';
					$responce['data'] = $temp;
					$responce['msg'] = 'No Attendance Found !!';
				}else{
					$responce['code'] = '1';
					//$responce['data'] = '';
					$responce['msg'] = 'No Attendance Found !!';
				}
			}else{
					$responce['code'] = '3';
					//$responce['data'] = '';
					$responce['msg'] = 'User removed from system contact to syste admin ...';
			}
		}
		
		echo json_encode($responce);
	}
	
	
	public function checkInOut() {
                  $responce=null;
			//$_POST['employee_code']
			date_default_timezone_set('Asia/Qatar');
                        $responce['code']='3';
			$responce['msg']='Error';
			$responce['button_text']='';
		if(isset($_POST['attendance_id']) && isset($_POST['employee_code'])
            && isset($_POST['address'])		
			&& isset($_POST['task_id']) && isset($_POST['out_lat']) && isset($_POST['out_long'])){
			//Qatar
			$pram['attendence_out_time']=date('H:i:s');
			$pram['out_latitude']= $_POST['out_lat'];
			$pram['out_longitude']= $_POST['out_long'];
			$pram['out_task_id']=$_POST['task_id'];
			$pram['out_address'] = $_POST['address'];
			$where['attendence_id'] = $_POST['attendance_id'];
			$where['employee_id']=$_POST['employee_code'];
			
			
			$temp = $this->Base_Models->UpadateValue('htco_attendence_details',$pram,$where);
			if($temp>0){
				$responce['code']='1';
				$responce['msg']='You have been just checked out.';
				$responce['button_text']='Check In'; 
			}
		}else if(isset($_POST['employee_code']) && isset($_POST['address'])
			&& isset($_POST['task_id']) && isset($_POST['in_lat']) && isset($_POST['in_long'])){
			
			$parm['employee_id']=$_POST['employee_code'];
			$parm['attendence_date']=date('Y-m-d');
			$parm['attendence_in_time']=date('H:i:s');
			$parm['attendence_status']='1';
			$parm['in_longitude']=$_POST['in_lat'];
			$parm['in_latitude']=$_POST['in_long'];
			$parm['in_task_id']=$_POST['task_id'];
			$parm['in_address'] = $_POST['address'];
			$temp=$this->Base_Models->AddValues('htco_attendence_details',$parm);
			
			if($temp>0){
				$responce['code']='0';
				$responce['msg']='You have been just checked in.';
				$responce['button_text']='Check Out';
				$responce['attendance_id'] = $temp;
			}

			//'attendence_out_time'=> ,
		}else if(isset($_POST['attendance_id']) && isset($_POST['employee_code']) 
			&& isset($_POST['address'])
			&& isset($_POST['out_lat']) && isset($_POST['out_long'])){
			
			$pram['attendence_out_time']=date('H:i:s');
			$pram['out_latitude']= $_POST['out_lat'];
			$pram['out_longitude']= $_POST['out_long'];
			$pram['out_address'] = $_POST['address'];
			$where['attendence_id'] = $_POST['attendance_id'];
			$where['employee_id']=$_POST['employee_code'];
		
			$temp = $this->Base_Models->UpadateValue('htco_attendence_details',$pram,$where);
			if($temp>0){
				$responce['code']='1';
				$responce['msg']='You have been just checked out.';
                $responce['button_text']='Check In'; 
			}
		}else if(isset($_POST['employee_code']) && isset($_POST['address'])
			&& isset($_POST['in_lat']) && isset($_POST['in_long'])){
			
			$parm['employee_id']=$_POST['employee_code'];
			$parm['attendence_date']=date('Y-m-d');
			$parm['attendence_in_time']=date('H:i:s');
			$parm['attendence_status']='1';
			$parm['in_longitude']=$_POST['in_lat'];
			$parm['in_latitude']=$_POST['in_long'];
			$parm['in_address'] = $_POST['address'];
			
			$temp=$this->Base_Models->AddValues('htco_attendence_details',$parm);
			
			if($temp>0){
				$responce['code']='0';
				$responce['msg']='You have been just checked in.';
				$responce['button_text']='Check Out';
				$responce['attendance_id'] = $temp;
			}

			//'attendence_out_time'=> ,
		}else{
			$responce['code']='2';
			$responce['msg']='Param not match';			
		}
		echo json_encode($responce);

	}
	public function login() {

		if(isset($_POST['employee_code']) && isset($_POST['employee_password']) && count($_POST)==2){
			$profile=$this->Base_Models->GetAllValues ("htco_employee_master",$_POST);
			if(count($profile)==1){
			$responce['code']='0';
			$responce['msg']='Login Done';
//			$profile['employee_status']="1";//0 : Pending  / 1 : Active / 2 : deactive / 3 : removed
			$responce['data']['profile']=$profile;
			//$privilege=$this->Base_Models->GetAllValues ("htco_privilege",$profile['employee_id']);
$privilege['profile']['status']="0";
$privilege['profile']['msg']="active";
$privilege['profile']['reason']="control profile button";

$privilege['task']['status']="1";
$privilege['task']['msg']="active";
$privilege['task']['reason']="control task list call and button";
$privilege['task']['apiurl']=base_url();
$privilege['task']['param']= array(array('key' => "employee_code"), array('key' => "date_start") , array('key' => "date_end") );

$privilege['attendance']['status']="0";
$privilege['attendance']['msg']="active";
$privilege['attendance']['reason']="control attendance list call and button";
$privilege['attendance']['apiurl']=base_url();
$privilege['attendance']['param']= array(array('key' => "employee_code"), array('key' => "date_start") , array('key' => "date_end") );

$privilege['maptask']['status']="0";
$privilege['maptask']['msg']="active";
$privilege['maptask']['reason']="control map task list display or not";
$privilege['maptask']['apiurl']=base_url();
$privilege['maptask']['param']= array( array('key' => "employee_code"), array('key' => "date_start") , array('key' => "date_end") );


$privilege['mapcheckin']['status']="0";
$privilege['mapcheckin']['msg']="active";
$privilege['mapcheckin']['att_code']="1";
if($profile>0){
	$table_name = 'htco_attendence_details';
	$where['employee_id'] = $profile[0]['employee_id'];
	$where['out_latitude'] = 0;
	$where['out_longitude'] = 0;
	date_default_timezone_set('Asia/Qatar');
	$where['attendence_date'] = date("Y-m-d");
	$select[] = 'attendence_id'; 

	//$cust_qury = 'SELECT attendence_id FROM htco_attendence_details WHERE employee_id = '.$profile[0]['employee_id'].' and out_latitude = 0 and out_longitude = 0 ORDER BY attendence_id DESC';
	//$temp = $this->Base_Models->CustomeQuary();
	$temp = $this->Base_Models->GetAllValues($table_name,$where,$select);
		if(count($temp) > 0){
			$privilege['mapcheckin']['att_code']="0";
			$privilege['mapcheckin']['att_id'] = $temp[count($temp)-1]['attendence_id'];
		}
}
$privilege['mapcheckin']['reason']="control mapcheckin button display or not";
$privilege['mapcheckin']['apiurl']=base_url("index.php/Api/Login/checkInOut");
$privilege['mapcheckin']['param']= array( array('key' => "employee_code"), array('key' => "in_lat") , array('key' => "in_long") , array('key' => "out_lat"), array('key' => "out_long"), array('key' => "attendance_id") , array('key' => "task_id"),
 array('key' => "address") );


$privilege['attendance']['apiurl']=base_url("index.php/Api/Login/getTaskList");
$privilege['attendance']['param']= array(array('key' => "employee_code"), array('key' => "date_start") , array('key' => "date_end") );
$privilege['maptask']['apiurl']=base_url("index.php/Api/Login/getMapTaskList");
$privilege['maptask']['param']= array( array('key' => "employee_code"), array('key' => "date_start") , array('key' => "date_end") );


$responce['data']['privilege']=$privilege;

			echo json_encode($responce);

			}else{
			$responce['code']='2';
			$responce['msg']='Login Faild';
			echo json_encode($responce);
			}
		}else{

			$responce['code']='1';

			$responce['post']= implode(" ",$_POST) ;
			$responce['msg']='In valid values';
			echo json_encode($responce);
		}
	}
	
}
?>