<?php
require_once APPPATH . 'core/Base_Controller.php';
if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
#[\AllowDynamicProperties]
class MapActivity extends Base_Controller {
	public function __construct() {
		parent::__construct ();
	}
	public function mapcheckin(){
		if(isset($_POST['employee_code']) && isset($_POST['date'])  && isset($_POST['in'])   && isset($_POST['out']) && isset($_POST['attendance_id'])  && isset($_POST['task_id']) && count($_POST)==6){

//case 1 (attendance_id 0/null) =>  insert attendance


//case 2 (attendance_id val) but (in exist ) =>  add attendance


//case 3 (attendance_id val) but (in / out time exist) =>  update attendance


//case 4 (attendance_id val) but ( out time exist) =>  update attendance

//case 5 (attendance_id val) but (in / out not found ) =>  error

//case 6 (task_id,date) not impact on existing case 


		}else{
			$responce['code']='1';
			$responce['msg']='In valid details';
			echo json_encode($responce);
		}
	
	}
/*
	public function login() {

		if(isset($_POST['employee_code']) && isset($_POST['employee_password']) && count($_POST)==2){
			$profile=$this->Base_Models->GetAllValues ("htco_employee_master",$_POST);
			if(count($profile)==1){
			$responce['code']='0';
			$responce['msg']='Login Done';
//			$profile['employee_status']="1";//0 : Pending  / 1 : Active / 2 : deactive / 3 : removed
			$responce['data']['profile']=$profile;
			//$privilege=$this->Base_Models->GetAllValues ("htco_privilege",$profile['employee_id']);
$privilege['profile']['status']="0";
$privilege['profile']['msg']="active";
$privilege['profile']['reason']="control profile button";

$privilege['task']['status']="0";
$privilege['task']['msg']="active";
$privilege['task']['reason']="control task list call and button";
$privilege['task']['apiurl']=base_url();
$privilege['task']['param']= array(array('key' => "employee_code"), array('key' => "date_start") , array('key' => "date_end") );

$privilege['attendance']['status']="0";
$privilege['attendance']['msg']="active";
$privilege['attendance']['reason']="control attendance list call and button";
$privilege['attendance']['apiurl']=base_url();
$privilege['attendance']['param']= array(array('key' => "employee_code"), array('key' => "date_start") , array('key' => "date_end") );

$privilege['maptask']['status']="0";
$privilege['maptask']['msg']="active";
$privilege['maptask']['reason']="control map task list display or not";
$privilege['maptask']['apiurl']=base_url();
$privilege['maptask']['param']= array( array('key' => "employee_code"), array('key' => "date_start") , array('key' => "date_end") );


$privilege['mapcheckin']['status']="0";
$privilege['mapcheckin']['msg']="active";
$privilege['mapcheckin']['reason']="control mapcheckin button display or not";
$privilege['mapcheckin']['apiurl']=base_url();
$privilege['mapcheckin']['param']= array( array('key' => "employee_code"), array('key' => "date"), array('key' => "in") , array('key' => "out"), array('key' => "attendance_id") , array('key' => "task_id") );
$responce['data']['privilege']=$privilege;
			echo json_encode($responce);
			}else{
			$responce['code']='2';
			$responce['msg']='Login Faild';
			echo json_encode($responce);
			}
		}else{
			$responce['code']='1';
			$responce['msg']='In valid values';
			echo json_encode($responce);
		}
	}
	*/
}
?>