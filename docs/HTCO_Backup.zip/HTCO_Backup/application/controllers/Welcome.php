<?php
defined('BASEPATH') OR exit('No direct script access allowed');

#[\AllowDynamicProperties]
class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function logout(){
	if (session_status() === PHP_SESSION_NONE) {
		session_start();
	}
	$_SESSION['employee_code']=""; 
	$_SESSION['employee_password']=""; 
	redirect(base_url("index.php/Welcome"));

}
	public function index($msg=""){
		$data['form_action']=base_url("index.php/Welcome/loginAccept");
		$data['msg']=$msg;
		$this->load->view('common/header');
		$this->load->view('forms/login',$data);
		$this->load->view('common/footer');

	}
 	public function loginAccept(){
	if(!isset($_POST['user']) || !isset($_POST['pwd'])){
		redirect(base_url("index.php/Welcome"));
		return;
	}
 if($_POST['user']=="HTCO-01" && $_POST['pwd']=="admin!@#"){
	if (session_status() === PHP_SESSION_NONE) { session_start(); }
	$_SESSION['employee_code']=$_POST['user']; 
	$_SESSION['employee_password']=$_POST['pwd']; 

 	redirect(base_url("index.php/Home"));

 }else{

$curl = curl_init();
$url="http://htco-erp.ethdigitalcampus.com/WebAPI/service/DC/authenticateEmployee";

curl_setopt_array($curl, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_SSL_VERIFYPEER => false,
	        CURLOPT_CUSTOMREQUEST => "POST",
		    CURLOPT_POSTFIELDS => "school_code=HTCO&imei_no=&employee_id=".$_POST['user']."&password=".$_POST['pwd']."&type=3&gcm_id=0",
		     CURLOPT_HTTPHEADER => array(
                 "Content-Type: application/x-www-form-urlencoded"
                  ),
                ));


$result = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);
$result = json_decode($result,true);
if ($err || empty($result)) {
//  echo "cURL Error #:" . $err;
  redirect(base_url("index.php/Welcome"));
} else {
// $response =  json_decode($result)->Employee_Details;
if($result['code']=="0"){
	if (session_status() === PHP_SESSION_NONE) { session_start(); }
	$_SESSION['employee_code']=$_POST['user']; 
	$_SESSION['employee_password']=$_POST['pwd']; 
redirect(base_url("index.php/Home"));
}else{
  redirect(base_url("index.php/Welcome/index/".$result['result']));
}

}


 }
 	}
function urlLogin($loginId,$passwod,$role=null){
	$curl = curl_init();
$url="http://htco-erp.ethdigitalcampus.com/WebAPI/service/DC/authenticateEmployee";
curl_setopt_array($curl, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_SSL_VERIFYPEER => false,
	        CURLOPT_CUSTOMREQUEST => "POST",
		    CURLOPT_POSTFIELDS => "school_code=HTCO&imei_no=0&employee_id=".$loginId."&password=".$passwod."&type=3&gcm_id=0",
             CURLOPT_HTTPHEADER => array(
                 "Content-Type: application/x-www-form-urlencoded"
                  ),
                ));

$result = curl_exec($curl);
$err = curl_error($curl);
curl_close($curl);
$result = json_decode($result,true);

if ($err || empty($result)) {
 // echo "cURL Error #:" . $err;
  redirect(base_url("index.php/Welcome"));
} else {
//  echo "RESULT " . $result;

// $response =  json_decode($result)->Employee_Details;
if($result['code']=="0"){
	if (session_status() === PHP_SESSION_NONE) { session_start(); }
	$_SESSION['employee_code']=$loginId; 
	$_SESSION['employee_role']=$role; 
	$_SESSION['employee_password']=$passwod; 
redirect(base_url("index.php/Home"));
}else{
  redirect(base_url("index.php/Welcome/index/".$result['result']));
}

}


}

}
