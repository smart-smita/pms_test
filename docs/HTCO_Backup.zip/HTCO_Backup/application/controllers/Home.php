<?php
require_once APPPATH . 'core/Base_Controller.php';
if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
#[\AllowDynamicProperties]
class Home extends Base_Controller {
	public $selectChart = null;
	public function __construct() {
		parent::__construct ();
		if (! isset ( $_SESSION ['employee_code'] ) || $_SESSION ['employee_code'] == "") {
			redirect ( base_url ( "index.php/Welcome/index/your session has expired please re-login" ) );
		}
		$this->load->model ( 'model_chartjs/methodchartjsmodel' );
		$this->selectChart = new MethodChartJsModel ();

	}
	public function index() {
		$this->load->model ( 'jsGanttChartModel' );
		$this->jsGanttChartModel = new jsGanttChartModel ();
		
		
		$temp = $this->Base_Models->CustomeQuary ( "SELECT count(*) as cnt,project_status FROM `htco_project_master` GROUP BY project_status" );
		$data ['active_project'] = 0;
		$data ['inactive_project'] = 0;
		$data ['completed_project'] = 0;
		foreach ( $temp as $val ) {
			if ($val ['project_status'] == 2) {
				$data ['completed_project'] = $val ['cnt'];
			} elseif ($val ['project_status'] == 0 || $val ['project_status'] == 3) {
				$data ['inactive_project'] += $val ['cnt'];
			} elseif ($val ['project_status'] == 4 || $val ['project_status'] == 1) {
				$data ['active_project'] += $val ['cnt'];
			}
		}
		if (isset ( $_SESSION ['employee_id'] )) {
			$temp = $this->Base_Models->CustomeQuary ( "SELECT * FROM htco_employee_master WHERE employee_id=" . $_SESSION ['employee_id'] );
			$temp [0] ['dashboard'] = true;
			$temp [0] ['title'] = "Employee Profile";
			$data ['profile'] = $this->load->view ( 'employee_form', $temp [0], true );
		}
		$cdata = null;
		$cdata ['Column'] = "    dataTable.addColumn({ type: 'string', id: 'Position' });";
		$cdata ['Column'] .= "    dataTable.addColumn({ type: 'string', id: 'Name' });";
		$cdata ['Column'] .= "    dataTable.addColumn({ type: 'date', id: 'Start' });";
		$cdata ['Column'] .= "    dataTable.addColumn({ type: 'date', id: 'End' });";
		$temp = $this->Base_Models->CustomeQuary ( "select project_name as project_name, min(plan_start_date) as start_date,max(plan_end_date)as end_date,min(actual_start_date) as a_start_date,max(actual_end_date) as a_end_date from (select htco_project_task_master.*,htco_project_master.project_name from htco_project_task_master,htco_project_master where  htco_project_master.project_id=htco_project_task_master.project_id and htco_project_master.project_status in (1)) htco_project_task_master group by project_id ORDER BY start_date DESC" );
		
		$cdata ['value'] = "";
		foreach ( $temp as $key => $value ) {
			$start_date = strtotime ( $value ['start_date'] );
			$end_date = strtotime ( $value ['end_date'] );
			$a_start_date = strtotime ( $value ['a_start_date'] );
			$a_end_date = strtotime ( $value ['a_end_date'] );
			
			if ($value ['start_date'] == '0000-00-00')
				$start_date = strtotime ( date ('Y-m-d') );
			if ($value ['end_date'] == '0000-00-00')
				$end_date = $start_date;
			
			if ($start_date > $end_date) {
				$start_date = $end_date;
			}
			if ($value ['a_start_date'] == '0000-00-00')
				$a_start_date = $end_date;
			if ($value ['a_end_date'] == '0000-00-00')
				$a_end_date = $a_start_date;
			
			if ($a_start_date > $a_end_date) {
				$a_start_date = $a_end_date;
			}
			
			$cdata ['value'] .= "[ '" . $value ['project_name'] . "', 'Plan " . $value ['project_name'] . "', new Date(" . date ( "Y", $start_date ) . "," . date ( "m", $start_date ) . "," . date ( "d", $start_date ) . "), new Date(" . date ( "Y", $end_date ) . "," . date ( "m", $end_date ) . "," . date ( "d", $end_date ) . ") ],";
			$cdata ['value'] .= "[ '" . $value ['project_name'] . "', 'Actual " . $value ['project_name'] . "', new Date(" . date ( "Y", $a_start_date ) . "," . date ( "m", $a_start_date ) . "," . date ( "d", $a_start_date ) . "), new Date(" . date ( "Y", $a_end_date ) . "," . date ( "m", $a_end_date ) . "," . date ( "d", $a_end_date ) . ") ],";
		}
		$cdata ['value'] = rtrim ( $cdata ['value'], ',' );
		// print_r($cdata);
		// exit();
		$data ['timeline'] = $this->load->view ( "project_chart", $cdata, true );
		
		$temp_table = array ();
		$temp = $this->Base_Models->CustomeQuary ( "SELECT * FROM htco_project_master WHERE (htco_project_master.project_status=0 OR htco_project_master.project_status=1)" );
		$temp1 = $this->Base_Models->CustomeQuary ( "SELECT *, SUM(htco_project_task_master.plan_hrs) as sum_plan_hrs,SUM(htco_project_task_master.actual_hrs) as sum_actual_hrs, MIN(htco_project_task_master.plan_start_date) as min_plan_start_date, MAX(htco_project_task_master.plan_end_date) as max_plan_end_date FROM htco_project_task_master WHERE htco_project_task_master.employee_project_status=0 GROUP BY project_id,task_id" );
		$temp12 = $this->Base_Models->CustomeQuary ( "SELECT * FROM `htco_discipline_task_master` WHERE htco_discipline_task_master.task_status=1" );
		foreach ( $temp as $key => $val ) {
			$value2 = array();
			foreach ( $temp1 as $val1 )
				if ($val ['project_id'] == $val1 ['project_id']) {
					$value1 = array();
					foreach ( $temp12 as $val2 ) {
						if ($val ['project_id'] == $val2 ['project_id'] && $val1 ['task_id'] == $val2 ['discipline_id']) {
							$value1 [$val ['project_id'] . $val1 ['task_id'] . $val2 ['dt_id']] = array (
									"title" => $val2 ['task_description'],
									"start_date" => $val2 ['task_start_datetime'],
									"end_date" => $val2 ['task_end_datetime'],
									"resource_name" => "",
									"open" => 0,
									"percentage" => 100 
							);
						}
					}
					$value2 [$val ['project_id'] . $val1 ['task_id']] = array (
							"title" => $val1 ['task_name'],
							"start_date" => $val1 ['min_plan_start_date'],
							"end_date" => $val1 ['max_plan_end_date'],
							"resource_name" => "",
							"percentage" => round ( ($val1 ['sum_actual_hrs'] * 100) / $val1 ['sum_plan_hrs'] ),
							"open" => 0 
					);
					if (is_array($value1) && count ( $value1 ) > 0) {
						$value2 [$val ['project_id'] . $val1 ['task_id']] ['data'] = $value1;
						$value2 [$val ['project_id'] . $val1 ['task_id']] ['is_group'] = 1;
					}
				}
			$value3 = array (
					"title" => $val ['project_name'] . " (" . $val ['project_code'] . ")",
					"start_date" => $val ['project_date'],
					"open" => 0,
					"note" => $val ['project_description'] 
			);
			$temp_table ['table_data'] [$val ['project_id']] = $value3;
			if (is_array($value2) && count ( $value2 ) > 0) {
				$temp_table ['table_data'] [$val ['project_id']] ['data'] = $value2;
				$temp_table ['table_data'] [$val ['project_id']] ['is_group'] = 1;
			} else {
				$temp_table ['table_data'] [$val ['project_id']] ['start_date'] = $val ['project_date'];
				$temp_table ['table_data'] [$val ['project_id']] ['end_date'] = $val ['project_date'];
			}
		}
		// echo "<pre>";
		// print_r ( $temp_table );
		// exit ();

		//$bar_status
		
		$data ['timeline_new'] = $this->jsGanttChartModel->defaultChart ( $temp_table );
		
		// BAR Chart
		$data['project_abstract'] = $this->getProjectAbstract(); 
		$data['task_abstract_url'] = base_url('index.php/Home/getTaskAbstract');
		$data['project_list'] = $this->Base_Models->CustomeQuary ( "SELECT project_name,project_code,project_id FROM htco_project_master WHERE htco_project_master.project_status<3" );

		$this->view ( "dashboard", $data );
	}
	public function getProjectAbstract(){

// full prject abstract 
// SELECT htco_project_master.*,SUM(plan_hrs ) as p_hrs, SUM( actual_hrs ) as a_hrs ,min(plan_start_date) as p_start_date, max(plan_end_date) p_end_date,
// if(min(actual_start_date)='0000-00-00',min(plan_start_date) , min(actual_start_date)) as a_start_date , 
// if(max(actual_end_date)='0000-00-00',min(plan_start_date) , max(actual_end_date)) as a_end_date 
// FROM  `htco_project_task_master` inner join htco_project_master on htco_project_master.project_id=htco_project_task_master.project_id
// GROUP BY  `project_id`

		$chart_data = null;
		$temp = $this->Base_Models->CustomeQuary ( "SELECT htco_project_master.*,SUM(plan_hrs ) as p_hrs, SUM( actual_hrs ) as a_hrs ,min(plan_start_date) as p_start_date, max(plan_end_date) p_end_date,
			if(min(actual_start_date)='0000-00-00',min(plan_start_date) , min(actual_start_date)) as a_start_date , 
			if(max(actual_end_date)='0000-00-00',min(plan_start_date) , max(actual_end_date)) as a_end_date 
			FROM  `htco_project_task_master` inner join htco_project_master on htco_project_master.project_id=htco_project_task_master.project_id
			GROUP BY  `project_id`");
		$chart_data [0] ['title'] = "Project Planned Hrs.";
		$chart_data [0] ['type'] = "bar";
		$chart_data [0] ['background_color'] = "Red";
		$chart_data [0] ['values'] = array();
		$chart_data [1] ['title'] = "Project Actual Hrs.";
		$chart_data [1] ['type'] = "bar";
		$chart_data [1] ['background_color'] = "Purple";
		$chart_data [1] ['values'] = array();
		foreach ($temp as $key => $value) {
//			$value1['label']=$value['project_name'].' '.$value['a_start_date'].' / '.$value['a_end_date'];
			$value1['label']=$value['project_code'];
			$value1['value']=$value['p_hrs'];
			array_push($chart_data [0] ['values'], $value1);
//			$value1['label']=$value['project_name'].' '.$value['p_start_date'].' / '.$value['p_end_date'];
			$value1['label']=$value['project_code'];
			$value1['value']=$value['a_hrs'];
			array_push($chart_data [1] ['values'], $value1);
		}
		return $this->selectChart->combineLineBarChart ( "Project Abstract Chart", $chart_data, "Projects", "Hrs.", false, 'width="100" height="50"' );
	}
	public function getTaskAbstract($project_id=null){
		// prject work abstract

		// SELECT htco_project_master.*,SUM(plan_hrs ) as p_hrs, SUM( actual_hrs ) as a_hrs ,min(plan_start_date) as p_start_date, max(plan_end_date) p_end_date,
		// if(min(actual_start_date)='0000-00-00',min(plan_start_date) , min(actual_start_date)) as a_start_date , 
		// if(max(actual_end_date)='0000-00-00',min(plan_start_date) , max(actual_end_date)) as a_end_date ,
		// sum(htco_discipline_task_master.work_hrs) as task_work_hts , SUM( TIMEDIFF(  htco_discipline_task_master.task_start_datetime,  htco_discipline_task_master.task_end_datetime ) ) as task_a_work_hts ,
		// if(min(htco_discipline_task_master.task_start_datetime)='0000-00-00',min(plan_start_date) , min(htco_discipline_task_master.task_start_datetime)) as a_end_date ,
		// if(max(htco_discipline_task_master.task_end_datetime)='0000-00-00',min(plan_start_date) , max(htco_discipline_task_master.task_end_datetime)) as a_end_date ,
		// htco_discipline_master.discipline_name as discipline_name,htco_discipline_master.class_code as discipline_code,GROUP_CONCAT(htco_discipline_task_master.task_description) as task_description,count(htco_discipline_task_master.discipline_id) as task_count
		// FROM  `htco_project_task_master` ,  htco_discipline_task_master , htco_discipline_master,htco_project_master
		// where htco_discipline_task_master.discipline_id=htco_discipline_master.id and 
		// htco_discipline_task_master.discipline_id=htco_project_task_master.task_id and
		// htco_discipline_task_master.project_id=htco_project_master.project_id and 
		// htco_project_task_master.project_id=htco_project_master.project_id  
		// GROUP BY  htco_discipline_task_master.discipline_id
		if(isset($_POST['project_id'])){
			$project_id = $_POST['project_id'];
		}
		$temp = $this->Base_Models->CustomeQuary ( "SELECT htco_project_master.*,SUM(plan_hrs ) as p_hrs, SUM( actual_hrs ) as a_hrs ,min(plan_start_date) as p_start_date, max(plan_end_date) p_end_date,
				if(min(actual_start_date)='0000-00-00',min(plan_start_date) , min(actual_start_date)) as a_start_date , 
				if(max(actual_end_date)='0000-00-00',min(plan_start_date) , max(actual_end_date)) as a_end_date ,
				sum(htco_discipline_task_master.work_hrs) as task_work_hts , SUM( TIMEDIFF(  htco_discipline_task_master.task_start_datetime,  htco_discipline_task_master.task_end_datetime ) ) as task_a_work_hts ,
				if(min(htco_discipline_task_master.task_start_datetime)='0000-00-00',min(plan_start_date) , min(htco_discipline_task_master.task_start_datetime)) as a_end_date ,
				if(max(htco_discipline_task_master.task_end_datetime)='0000-00-00',min(plan_start_date) , max(htco_discipline_task_master.task_end_datetime)) as a_end_date ,
				htco_discipline_master.discipline_name as discipline_name,htco_discipline_master.class_code as discipline_code,GROUP_CONCAT(htco_discipline_task_master.task_description) as task_description,count(htco_discipline_task_master.discipline_id) as task_count
				FROM  `htco_project_task_master` ,  htco_discipline_task_master , htco_discipline_master,htco_project_master
				where htco_discipline_task_master.discipline_id=htco_discipline_master.id and 
				htco_discipline_task_master.discipline_id=htco_project_task_master.task_id and
				htco_discipline_task_master.project_id=htco_project_master.project_id and 
				htco_project_task_master.project_id=htco_project_master.project_id  and
				htco_project_master.project_id =$project_id
				GROUP BY  htco_discipline_task_master.discipline_id");

		$chart_data [0] ['title'] = "Disciplines Planned Hrs.";
		$chart_data [0] ['type'] = "bar";
		$chart_data [0] ['background_color'] = "Red";
		$chart_data [0] ['values'] = array();
		$chart_data [1] ['title'] = "Disciplines Actual Hrs.";
		$chart_data [1] ['type'] = "bar";
		$chart_data [1] ['background_color'] = "Purple";
		$chart_data [1] ['values'] = array();
			foreach ($temp as $key => $value) {
				$value1['label']=$value['discipline_name'].' / '.$value['task_count'];
				$value1['value']=($value['task_work_hts']<0?0:$value['task_work_hts']);
				array_push($chart_data [0] ['values'], $value1);
				$value1['label']=$value['discipline_name'].' / '.$value['task_count'];
				$value1['value']=($value['task_a_work_hts']<0?0:$value['task_a_work_hts']);
				array_push($chart_data [1] ['values'], $value1);
			}
		echo $this->selectChart->combineLineBarChart ( "Project Task Abstract Chart", $chart_data, "Disciplines", "Hrs.", false, 'width="80" height="50"' );
	}
}
?>