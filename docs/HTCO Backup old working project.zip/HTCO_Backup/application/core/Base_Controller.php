<?php
if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
#[\AllowDynamicProperties]
class Base_Controller extends CI_Controller {
	public $Base_Models = NULL;
	public function __construct() {
		parent::__construct ();
 		$this->load->model ( "base_models" );
 		$this->Base_Models = new Base_Models ();
		if (session_status() === PHP_SESSION_NONE) {
			session_start ();
		}
		if(isset($_SESSION['employee_code'])){
			$this->check_employee_id();
		}
	}
	public function check_employee_id(){
		if(!isset($_SESSION['employee_id'])){
			$data = $this->Base_Models->CustomeQuary("SELECT employee_id FROM htco_employee_master WHERE employee_code='".$_SESSION['employee_code']."'");
			if(is_array($data) && count($data)>0){
				$_SESSION['employee_id'] = $data[0]['employee_id'];
			}
		}
	}
	public function view($url, $data = null) {
		if (isset ( $url )) {
			$this->load->view ( 'common/header' );
			$this->load->view ( 'common/top' );
			$this->load->view ( 'common/left' );
			if (isset ( $data ))
				$this->load->view ( $url, $data );
			else
				$this->load->view ( $url );
			$this->load->view ( 'common/right' );
			$this->load->view ( 'common/footer' );
		}
	}
}
?>