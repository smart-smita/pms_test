<?php
require_once APPPATH . 'core/Base_Controller.php';
if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
#[\AllowDynamicProperties]
class ProjectMaster extends Base_Controller {
	public function __construct() {
		parent::__construct ();
			if(!isset($_SESSION['employee_code']) || $_SESSION['employee_code'] == ""){
				  redirect(base_url("index.php/Welcome/index/your session has expired please re-login"));
			}

	}
	public function index() {
		$data['display_contents']=array(
			"id" => "ID",
			"project_code" => "Code",
			"project_name" => "Project Name",
			"project_date" => "Project Date",
			"project_client_code" => "Client Code",
			"project_client_name" => "Client Name",
			"action" => "Action"
		);
		$data['table_data'] = $this->Base_Models->CustomeQuary("SELECT * FROM htco_project_master WHERE project_status!=5");
		if (is_array($data['table_data'])) {
			foreach($data['table_data'] as $key=>$val){
				$data['table_data'][$key]['action']="";
				$data['table_data'][$key]['id'] = $key + 1;
				$data['table_data'][$key]['action'] = "<button class='btn btn-info' onclick='window.location=\"".base_url(index_page().'ProjectMaster/addProject/'.$val['project_id'])."\"'><i class='fa fa-edit'></i></button>";
				if($val['project_status']==5 || $val['project_status']==3 )
					$data['table_data'][$key]['tr_class'] = "danger";
				

				if($val['project_status']==0){ // REMOVE
		$data['table_data'][$key]['tr_class'] = "warning";

				$data['table_data'][$key]['action'] .= " 
								<button class='btn btn-warning ' 
									title='Activate Project'
									data-target = '#con-close-modal'
									form-data-url='" . base_url ( index_page().'ProjectMaster/operationProject/'.$val['project_id'] ) . "'
									modal-button-text='Activate'
									modal-title = 'Activate Project'
									modal-data = 'Are sure to active project?<input type=\"hidden\" name=\"status\" value=\"1\">'
									onclick='loadModal(this);'><i class='fa fa-unlock'></i></button> 
							";
				$data['table_data'][$key]['action'] .= "
								<button class='btn btn-warning ' 
									title='Remove Project'
									data-target = '#con-close-modal'
									form-data-url='" . base_url ( index_page().'ProjectMaster/operationProject/'.$val['project_id'] ) . "'
									modal-button-text='Remove'
									modal-title = 'Remove Project'
									modal-data = 'Are sure to Remove project?<input type=\"hidden\" name=\"status\" value=\"5\">'
									onclick='loadModal(this);'><i class='fa fa-trash'></i></button> 
							";
				}elseif($val['project_status']==1){ // CANCEL
						$data['table_data'][$key]['tr_class'] = "primary";

								$data['table_data'][$key]['action'] .= "
								<button class='btn btn-warning ' 
									title='Cancel Project'
									data-target = '#con-close-modal'
									form-data-url='" . base_url ( index_page().'ProjectMaster/operationProject/'.$val['project_id'] ) . "'
									modal-button-text='Cancel'
									modal-title = 'Cancel Project'
									modal-data = 'Are sure to Cancel project?<input type=\"hidden\" name=\"status\" value=\"3\">'
									onclick='loadModal(this);'><i class='fa fa-close'></i></button> 
							";
				}
			}
		}
		$data['title'] = "<button class='btn btn-primary pull-right' style='margin-top: -45px;' onclick='window.location=\"".base_url(index_page().'ProjectMaster/addProject')."\"'><i class='fa fa-plus'></i></button>";
		$view_data['content'] = $this->load->view ( "common/table-view",$data ,true);
		$view_data['title'] = "Manage Project";
		$this->view("load_view",$view_data);
	}
	public function operationProject($id){
		$respnse['message']="fail";
		if(isset($_POST['status'])){
			$temp = $this->Base_Models->UpadateValue("htco_project_master",array("project_status"=>$_POST['status']),array("project_id"=>$id));
			if($temp==1){
				$respnse['message']="done";
				$respnse['load']=array(
								"events" => array(
									($_POST['status']==5?"row_hide":"button_hide")
								),
								"id" => array(
									0
								),
								"data" => array(
									($_POST['status']==5?"":($_POST['status']==1?"<button class='btn btn-warning ' 
								title='Cancel Project'
								data-target = '#con-close-modal'
								form-data-url='" . base_url ( index_page().'ProjectMaster/addProject/'.$id ) . "'
								modal-button-text='Cancel'
								modal-title = 'Cancel Project'
								modal-data = 'Are sure to Cancel project?<input type=\"hidden\" name=\"status\" value=\"3\">'
								onclick='loadModal(this);'><i class='fa fa-close'></i></button>":""))
								)
						);
			}
		}
		echo json_encode($respnse);
	}
	public function addProject($id = null) {
		$data = null;
		$data['action']=base_url(index_page()."ProjectMaster/acceptProjectDetails");
		if(isset($id)){
			$temp = $this->Base_Models->CustomeQuary("SELECT * FROM htco_project_master WHERE project_id=".$id);
			if(is_array($temp) && count($temp)>0){
				$data = $temp[0];
				$data['discipline_data'] = $this->Base_Models->CustomeQuary("SELECT * FROM htco_project_task_master WHERE project_id=".$id." AND employee_project_status!=5");
				$data['action']=base_url(index_page()."ProjectMaster/acceptProjectDetails/".$id);
			}else
				redirect(base_url('index.php/ProjectMaster'));
		}
		$data['discipline']=$this->Base_Models->GetAllValues("htco_discipline_master",array("discipline_status"=>1));
		$this->view ( "forms/add_project_view" ,$data);
	}
	public function acceptProjectDetails($id=null){
		$htco_project_master['project_code']=$_POST['project_code'];
		$htco_project_master['project_name']=$_POST['project_name'];
		$htco_project_master['project_date']=date("Y-m-d", strtotime( $_POST['project_date']));
		$htco_project_master['project_client_code']=$_POST['project_client_code'];
		$htco_project_master['project_client_name']=$_POST['project_client_name'];
		$htco_project_master['project_description']=$_POST['project_description'];
		$htco_project_master['project_address']=$_POST['project_address'];
		$htco_project_master['project_lat']=$_POST['project_lat'];
		$htco_project_master['project_lng']=$_POST['project_lng'];
		$htco_project_master['project_radious']=$_POST['project_radious'];
		$temp = null;
		if(isset($id)){
			$temp = $this->Base_Models->UpadateValue("htco_project_master",$htco_project_master,array("project_id"=>$id));
			//$existing_discipline = $this->Base_Models->UpadateValue("htco_project_task_master",array("employee_project_status"=>5),array("project_id" => $temp));
			$responce['message']="Project Updated Successfully";
			$responce['status']="done";
		}else{
			$temp = $this->Base_Models->AddValues("htco_project_master",$htco_project_master);
			if(isset($_POST['discipline_id'])){
				$discipline_id=$_POST['discipline_id'];
				$discipline_name=$_POST['discipline_name'];
				$discipline_start_date=$_POST['discipline_start_date'];
				$discipline_end_date=$_POST['discipline_end_date'];
				$discipline_hrs=$_POST['discipline_hrs'];
				for($i = 0 ; $i < count($discipline_id);$i++){
					$htco_project_task_master['project_id'] = $temp;
					$htco_project_task_master['task_id'] = $discipline_id[$i];
					$htco_project_task_master['task_name'] = $discipline_name[$i];
					$htco_project_task_master['plan_start_date'] = date('Y-m-d', strtotime($discipline_start_date[$i]));
					$htco_project_task_master['plan_end_date'] = date('Y-m-d', strtotime($discipline_end_date[$i]));
					$htco_project_task_master['plan_hrs'] = $discipline_hrs[$i];
					$this->Base_Models->AddValues("htco_project_task_master",$htco_project_task_master);
				}
			}
			$responce['message']="Project Added Successfully";
			$responce['status']="done";
		}
			$responce['url']=base_url(index_page()."ProjectMaster/addProject");
		echo json_encode($responce);
		/*discipline
		end_date
		start_date
		hrs*/
	}
	public function addWorkList() {
		$data = array ();
		$data ['id'] = 1;
		$data ['title'] = "Project Master / Manage Project Work";
		$where ['project_status'] = 1;
		$data['project_list']=$this->Base_Models->GetAllValues("htco_project_master",$where);
		$data['task_list_url']=base_url("index.php/ProjectMaster/getWorkList");
		$data['add_task_url']=base_url("index.php/ProjectMaster/addNewWorkList");
		$data['add_task_log_url']=base_url("index.php/ProjectMaster/addTaskTimeLog");
		$this->view ( "allocate_tasks_to_project", $data );
	}
	public function getWorkList($id=null) {
			$responce = array ();
			if(isset($_POST['project_id'])){
				$responce['code']="0";
				$responce['task_list']=$this->Base_Models->CustomeQuary("
					SELECT employee_project_id, employee_project_status,
						task_id,task_name, actual_hrs, plan_hrs,
						(IF(plan_start_date='0000-00-00','-',plan_start_date)) as plan_start_date, 
						(IF(plan_end_date='0000-00-00','-',plan_end_date)) as plan_end_date, 
						(IF(actual_start_date='0000-00-00','-',actual_start_date)) as actual_start_date, 
						(IF(actual_end_date='0000-00-00','-',actual_end_date)) as actual_end_date 						
					FROM htco_project_task_master 
					WHERE project_id=".$_POST['project_id']);
				echo json_encode($responce);			
			}else{
				$responce['code']="1";
				$responce['msg']="Task Not Found !!";
				echo json_encode($responce);
			}
	}
	public function addNewWorkList($id=null,$id1=null){
		//add_discipline_form_view
		if(isset($_POST['actual_start_date']) && isset($id)){
			if(isset($id1)){
				$htco_project_task_master['actual_start_date'] = ($_POST['actual_start_date']!='')?date('Y-m-d', strtotime($_POST['actual_start_date'])):"";
				$htco_project_task_master['actual_end_date'] = ($_POST['actual_end_date']!='')?date('Y-m-d', strtotime($_POST['actual_end_date'])):"";
				$htco_project_task_master['actual_hrs'] = $_POST['actual_hrs'];
				$this->Base_Models->UpadateValue("htco_project_task_master",$htco_project_task_master,array("employee_project_id"=>$id));								
				echo json_encode(
					array(
						"message"=>"done",
						"load" => array(
								"events" => array(
									"block_replace",
									"block_replace",
									"block_replace"
								),
								"id" => array(
									2,
									3,
									4
								),
								"data" => array(
									$htco_project_task_master['actual_start_date'],
									$htco_project_task_master['actual_end_date'],
									$htco_project_task_master['actual_hrs']
								)
							)
						)
					);
			}else{
				$htco_project_task_master['project_id'] = $id;
				$htco_project_task_master['task_id'] = $_POST['task_id'];
				$htco_project_task_master['task_name'] = $_POST['task_name'];
				$htco_project_task_master['plan_start_date'] = date('Y-m-d', strtotime($_POST['plan_start_date']));
				$htco_project_task_master['plan_end_date'] = date('Y-m-d', strtotime($_POST['plan_end_date']));
				$htco_project_task_master['plan_hrs'] = $_POST['plan_hrs'];
				$htco_project_task_master['actual_start_date'] = ($_POST['actual_start_date']!='')?date('Y-m-d', strtotime($_POST['actual_start_date'])):"";
				$htco_project_task_master['actual_end_date'] = ($_POST['actual_end_date']!='')?date('Y-m-d', strtotime($_POST['actual_end_date'])):"";
				$htco_project_task_master['actual_hrs'] = $_POST['actual_hrs'];
				$temp = $this->Base_Models->AddValues("htco_project_task_master",$htco_project_task_master);
				echo json_encode(
					array(
						"message"=>"done",
						"script" => "getTaskList()"
						)
					);
			}
		}else{
			$data = null;
			if(isset($id)){
				$temp = $this->Base_Models->GetAllValues("htco_project_task_master",array("employee_project_id"=>$id));
				$data = $temp[0];
			}else{
				$data['discipline']=$this->Base_Models->GetAllValues("htco_discipline_master",array("discipline_status"=>1));
			}
			$data['title']="Discipline Form";
			$this->load->view('forms/add_discipline_form_view',$data);
		}
	}
	public function taskList($taks=null){

		for($i = 0 ; $i < count($discipline_id);$i++){
			$htco_project_task_master['project_id'] = $id;
			$htco_project_task_master['task_id'] = $discipline_id[$i];
			$htco_project_task_master['task_name'] = $discipline_name[$i];
			$htco_project_task_master['plan_start_date'] = date('Y-m-d', strtotime($discipline_start_date[$i]));
			$htco_project_task_master['plan_end_date'] = date('Y-m-d', strtotime($discipline_end_date[$i]));
			$htco_project_task_master['plan_hrs'] = $discipline_hrs[$i];
			$this->Base_Models->AddValues("htco_project_task_master",$htco_project_task_master);
		}
	}
	public function getDisciplineTask(){
		$data = array ();
		$data ['id'] = 1;
		$where = null;
		$data['title']="Project Master / Manage Tasks";
		$where ['project_status'] = 1;
		$data['project_list']=$this->Base_Models->GetAllValues("htco_project_master",$where,'project_id,project_name,project_date,project_code,project_client_name,project_client_code,project_description');
		//$where = null;
		//$where ['employee_project_status'] = 1;
		$data['discipline_list']=$this->Base_Models->GetAllValues("htco_project_task_master",null,'task_id,project_id,task_code,task_name');
		$data['task_list_url']=base_url("index.php/ProjectMaster/getTaskWorkList");
		$data['add_task_url']=base_url("index.php/ProjectMaster/addNewTaskWorkList");
		$data['add_task_log_url']=base_url("index.php/ProjectMaster/addTaskTimeLog");
		$this->view ( "allocate_discipline_tasks", $data );
	}
	public function getTaskWorkList(){
			$responce = array ();
			if(isset($_POST['project_id']) && isset($_POST['discipline_id'])){
				$responce['code']="0";
				$responce['task_list']=$this->Base_Models->CustomeQuary("
					SELECT dt_id, (SELECT employee_name FROM htco_employee_master WHERE htco_employee_master.employee_id=htco_discipline_task_master.employee_id) as employee_name,
						task_description, work_hrs, task_start_datetime, task_end_datetime, task_status
					FROM htco_discipline_task_master 
					WHERE project_id=".$_POST['project_id']." AND discipline_id=".$_POST['discipline_id']);
					$responce['project_id'] = $_POST['project_id'];
					$responce['discipline_id'] = $_POST['discipline_id'];
				echo json_encode($responce);			
			}else{
				$responce['code']="1";
				$responce['msg']="Task Not Found !!";
				echo json_encode($responce);
			}		
	}
		public function addNewTaskWorkList($id=null,$id1=null){
		//add_task_form_view
		if(isset($_POST['employee_id']) && isset($id)){
			// POST DATA
			if(isset($id) && !isset($id1)){
				// UPDATE
				$htco_project_task_master['employee_id'] = $_POST['employee_id'];
				$htco_project_task_master['task_description'] = $_POST['task_description'];
				$htco_project_task_master['task_start_datetime'] = (date_create_from_format('d/m/Y',$_POST['task_start_date'])->format('Y-m-d'))." ".$_POST['task_start_time'];
				$htco_project_task_master['task_end_datetime'] = (date_create_from_format('d/m/Y',$_POST['task_end_date'])->format('Y-m-d'))." ".$_POST['task_end_time'];
				$htco_project_task_master['work_hrs'] = $_POST['work_hrs'];
				$this->Base_Models->UpadateValue("htco_discipline_task_master",$htco_project_task_master,array("dt_id"=>$id));								
				echo json_encode(
					array(
						"message"=>"done",
						"load" => array(
								"events" => array(
									"block_replace",
									"block_replace",
									"block_replace",
									"block_replace"
								),
								"id" => array(
									2,
									3,
									4,
									5
								),
								"data" => array(
									$_POST['employee_name'],
									$htco_project_task_master['task_start_datetime'],
									$htco_project_task_master['task_end_datetime'],
									$htco_project_task_master['work_hrs']
								)
							)
						)
					);
			}else{
				// ADD
				$htco_project_task_master['project_id'] = $id;
				$htco_project_task_master['discipline_id'] = $id1;
				$htco_project_task_master['employee_id'] = $_POST['employee_id'];
				$htco_project_task_master['task_description'] = $_POST['task_description'];
				$htco_project_task_master['task_start_datetime'] = (date_create_from_format('d/m/Y',$_POST['task_start_date'])->format('Y-m-d'))." ".$_POST['task_start_time'];
				$htco_project_task_master['task_end_datetime'] = (date_create_from_format('d/m/Y',$_POST['task_end_date'])->format('Y-m-d'))." ".$_POST['task_end_time'];
				$htco_project_task_master['work_hrs'] = $_POST['work_hrs'];
				$htco_project_task_master['task_status'] = 1;
				$temp = $this->Base_Models->AddValues("htco_discipline_task_master",$htco_project_task_master);
				echo json_encode(
					array(
						"message"=>"done",
						"script" => "getTaskList()"
						)
					);
			}
		}else{
			// LOAD VIEW
			$data = null;
			if(isset($id) && isset($id1)){
				$temp = $this->Base_Models->CustomeQuary("
					SELECT htco_project_master.project_id, 
						CONCAT(htco_project_master.project_code,' ',htco_project_master.project_name) as project_name, 
						(SELECT CONCAT(htco_discipline_master.class_code,' ',htco_discipline_master.discipline_name) as discipline_name 
							FROM htco_discipline_master 
							WHERE htco_discipline_master.id=".$id1.") as discipline_name, 
						'".$id1."' as discipline_id 
					FROM htco_project_master 
					WHERE htco_project_master.project_id=".$id);
				$data = $temp[0];
			}elseif(isset($id)){
				$temp = $this->Base_Models->CustomeQuary("
					SELECT htco_discipline_task_master.*,
						(SELECT CONCAT(htco_project_master.project_code,' ',htco_project_master.project_name) as project_name 
							FROM htco_project_master 
							WHERE htco_project_master.project_id=htco_discipline_task_master.project_id ) as project_name, 
						(SELECT CONCAT(htco_discipline_master.class_code,' ',htco_discipline_master.discipline_name) as discipline_name 
							FROM htco_discipline_master 
							WHERE htco_discipline_master.id=htco_discipline_task_master.discipline_id) as discipline_name 
					from htco_discipline_task_master 
					WHERE dt_id=".$id);
				$data = $temp[0];
			}
			$data['employee'] = $this->Base_Models->CustomeQuary("
					SELECT htco_employee_master.employee_id, 
						CONCAT(htco_employee_master.employee_name,' (',htco_employee_master.employee_code,')') as employee_name 
					FROM htco_employee_master 
					WHERE htco_employee_master.employee_status=1");
			$data['title']="Task Allocation Form";
			$this->load->view('forms/add_task_form_view',$data);
		}
	}

	// Task Time Log 
	public function getTaskTimeLog(){
		$data = array ();
		$data ['id'] = 1;
		$data ['title'] = "Project Master / Edit Timesheet";
		$where = null;
		$where ['project_status'] = 1;
		$data['project_list']=$this->Base_Models->GetAllValues("htco_project_master",$where,'project_id,project_name,project_date,project_code,project_client_name,project_client_code,project_description');
		//$where = null;
		//$where ['employee_project_status'] = 1;
		$data['discipline_list']=$this->Base_Models->GetAllValues("htco_project_task_master",null,'task_id,project_id,task_code,task_name');
		$data['task_list_url']=base_url("index.php/ProjectMaster/getTaskTimeWorkList");
		$data['add_task_url']=base_url("index.php/ProjectMaster/addTaskTimeLog");
		$this->view ( "allocate_task_time_log_view", $data );
	}
	public function getTaskTimeWorkList($flag=null,$flag1=null){
		if(isset($flag)){
			$_POST['project_id']=$flag;
			$_POST['discipline_id']=$flag1;
		}
			$responce = array ();
			if(isset($_POST['project_id']) && isset($_POST['discipline_id'])){
				$responce['code']="0";
				$task_inner = "SELECT task_description FROM htco_discipline_task_master where htco_discipline_task_master.dt_id=htco_task_time_log_master.task_id";
				$dis_inner = "SELECT CONCAT(class_code,' - ',discipline_name) FROM htco_discipline_master where htco_discipline_master.id=htco_task_time_log_master.discipline_id";
				$responce['task_list']=$this->Base_Models->CustomeQuary("
					SELECT htco_task_time_log_master.*, (SELECT employee_name FROM htco_employee_master WHERE htco_employee_master.employee_id=htco_task_time_log_master.employee_id) as employee_name,
						(IF(htco_task_time_log_master.time_log_on=1,(".$dis_inner."),(".$task_inner."))) as task_description 
					FROM htco_task_time_log_master 
					WHERE project_id=".$_POST['project_id']." AND discipline_id=".$_POST['discipline_id']." ORDER BY task_date DESC");
				$responce['project_id'] = $_POST['project_id'];
				$responce['discipline_id'] = $_POST['discipline_id'];
				if(isset($flag)){
					$data['table_data']=$responce['task_list'];
					$data['display_contents']=array(
						"id" => "ID",
						"time_log_on" => "Log On",
						"task_description" => "Log Name",
						"task_date" => "Date Date",
						"task_hrs" => "Hrs."
					);
					foreach($data['table_data'] as $key=>$val){
						$data['table_data'][$key]['id']=$key+1;
						$data['table_data'][$key]['time_log_on']=($val['time_log_on']==1?"Discipline":"Task");
					}
					return $this->load->view('common/table-view',$data,true);
				}else{
					echo json_encode($responce);				
				}
			}else{
				$responce['code']="1";
				$responce['msg']="<font color='red'>No Task Or Discipline Found !!!</font>";
				echo json_encode($responce);
			}		
		
	}
	public function addTaskTimeLog($id=null,$id1=null,$id2=null){
		$data = null;
		if(isset($_POST['task_date']) && isset($id)){
			// POST DATA
			if(isset($id) && !isset($id1)){
				// UPDATE task
				$task_data = $this->Base_Models->GetAllValues("htco_task_time_log_master",array("time_log_id"=>$id));
				if(count($task_data)>0){
					//$htco_task_time_log_master['project_id'] = $task_data[0]['project_id'];
					//$htco_task_time_log_master['discipline_id'] = $task_data[0]['discipline_id'];
					//$htco_task_time_log_master['time_log_on'] = 0;
					//$htco_task_time_log_master['task_id'] = $id;
					//$htco_task_time_log_master['employee_id'] = $task_data[0]['employee_id'];
					$htco_task_time_log_master['task_date'] = (date_create_from_format('d/m/Y',$_POST['task_date'])->format('Y-m-d'));
					$htco_task_time_log_master['task_hrs'] = $_POST['task_hrs'];
					$this->Base_Models->UpadateValue("htco_task_time_log_master",$htco_task_time_log_master,array(
						"time_log_id" => $id
					));
					echo json_encode(
						array(
							"message"=>"done",
							"script" => "getTaskList()"
						));
				}else{
					echo json_encode(
					array(
						"message"=>"fail"
						)
					);

				}
			}else if(isset($id) && isset($id1)){
				$htco_task_time_log_master['project_id'] = $id;
				$htco_task_time_log_master['discipline_id'] = $id1;
				$htco_task_time_log_master['time_log_on'] = 1;
				if(isset($_POST['task_id']) && $_POST['task_id']!=0){
					$htco_task_time_log_master['time_log_on'] = 0;
					$htco_task_time_log_master['task_id'] = $_POST['task_id'];
				}
				$htco_task_time_log_master['employee_id'] = $_POST['employee_id'];
				$htco_task_time_log_master['task_date'] = (date_create_from_format('d/m/Y',$_POST['task_date'])->format('Y-m-d'));
				$htco_task_time_log_master['task_hrs'] = $_POST['task_hrs'];
				$htco_task_time_log_master['time_log_status'] = 1;
				$temp = $this->Base_Models->AddValues("htco_task_time_log_master",$htco_task_time_log_master);								
				if($temp > 0){
					echo json_encode(
						array(
							"message"=>"done",
							"script" => "getTaskList()"
						));
				}else{
					echo json_encode(
					array(
						"message"=>"fail"
						)
					);

				}	
			}
		}else{
			// LOAD VIEW
			$data = null;
			if(!is_numeric($id)){
				echo $this->getTaskTimeWorkList($id1,$id2);
			}else{
				if(isset($id) && isset($id1)){
					// Add VIEW
					$temp = $this->Base_Models->CustomeQuary("
						SELECT htco_project_master.project_id, 
							CONCAT(htco_project_master.project_code,' ',htco_project_master.project_name) as project_name, 
							(SELECT CONCAT(htco_discipline_master.class_code,' ',htco_discipline_master.discipline_name)
								FROM htco_discipline_master 
								WHERE htco_discipline_master.id=".$id1.") as discipline_name, 
							'".$id1."' as discipline_id
						FROM htco_project_master 
						WHERE htco_project_master.project_id=".$id);
					$data = $temp[0];
					//print_r($data);
					if(isset($id2)){
						$data['task_id'] = $id2;
					}
					$data['employee'] = $this->Base_Models->CustomeQuary("
						SELECT htco_employee_master.employee_id, 
							CONCAT(htco_employee_master.employee_name,' (',htco_employee_master.employee_code,')') as employee_name 
						FROM htco_employee_master 
						WHERE htco_employee_master.employee_status=1");
					$data['task'] = $this->Base_Models->CustomeQuary("
						SELECT dt_id as task_id, task_description
						FROM htco_discipline_task_master
						WHERE htco_discipline_task_master.task_status=1 AND project_id=".$id." AND discipline_id=".$id1);
				}elseif(isset($id)){
					// Update VIEW
					$task_inner = "SELECT task_description FROM htco_discipline_task_master where htco_discipline_task_master.dt_id=htco_task_time_log_master.task_id";
					$dis_inner = "SELECT CONCAT(class_code,' - ',discipline_name) FROM htco_discipline_master where htco_discipline_master.id=htco_task_time_log_master.discipline_id";
					$temp=$this->Base_Models->CustomeQuary("
						SELECT 
						(SELECT CONCAT(htco_project_master.project_code,' ',htco_project_master.project_name) 
								FROM htco_project_master 
								WHERE htco_project_master.project_id=htco_task_time_log_master.project_id ) as project_name, 
							(SELECT CONCAT(htco_discipline_master.class_code,' ',htco_discipline_master.discipline_name) 
								FROM htco_discipline_master 
								WHERE htco_discipline_master.id=htco_task_time_log_master.discipline_id) as discipline_name ,
						discipline_id, (SELECT employee_name FROM htco_employee_master WHERE htco_employee_master.employee_id=htco_task_time_log_master.employee_id) as employee_name,
							(IF(htco_task_time_log_master.time_log_on=1,(".$dis_inner."),(".$task_inner."))) as task_description, 
							task_hrs, time_log_on,
							task_date,
							time_log_status as task_status,time_log_id
						FROM htco_task_time_log_master 
						WHERE time_log_id=".$id);
					$data = $temp[0];					
				}
				$data['title']="Log Time Sheet";
				$this->load->view('forms/add_task_time_log_form_view',$data);
			}
		}
	}
	// Add Project Discipline or Task Wise Log Sheet 
		public function addWorkLogList() {
		$data = array ();
		$data ['id'] = 1;
		$data ['isDiscipline'] = 1;
		$data ['title'] = "Project Master / Log Timesheet";
		$where = null;
		$where ['project_status'] = 1;
		$data['project_list']=$this->Base_Models->GetAllValues("htco_project_master",$where,'project_id,project_name,project_date,project_code,project_client_name,project_client_code,project_description');
		//$where = null;
		//$where ['employee_project_status'] = 1;
		$data['discipline_list']=$this->Base_Models->GetAllValues("htco_project_task_master",null,'task_id,project_id,task_code,task_name');
		$data['task_list_url']=base_url("index.php/ProjectMaster/getWorkLogList");
		$data['add_task_url']=base_url("index.php/ProjectMaster/addTaskTimeLog");
		$this->view ( "allocate_task_time_log_view", $data );
	}
	public function getWorkLogList($id=null) {
			$responce = array ();
			if(isset($_POST['project_id'])){
				$responce['code']="0";
				$task_inner = "SELECT task_description FROM htco_discipline_task_master where htco_discipline_task_master.dt_id=htco_task_time_log_master.task_id";
				$dis_inner = "SELECT CONCAT(class_code,' - ',discipline_name) FROM htco_discipline_master where htco_discipline_master.id=htco_task_time_log_master.discipline_id";
				$responce['task_list']=$this->Base_Models->CustomeQuary("
					SELECT htco_task_time_log_master.*, MAX(htco_task_time_log_master.task_date) as task_date, SUM(htco_task_time_log_master.task_hrs) as task_hrs, (SELECT employee_name FROM htco_employee_master WHERE htco_employee_master.employee_id=htco_task_time_log_master.employee_id) as employee_name,
						(IF(htco_task_time_log_master.time_log_on=1,(".$dis_inner."),(".$task_inner."))) as task_description 
					FROM htco_task_time_log_master 
					WHERE project_id=".$_POST['project_id']." ".(isset($_POST['discipline_id'])&&$_POST['discipline_id']!=0?"AND discipline_id=".$_POST['discipline_id']:"")." GROUP BY discipline_id,task_id");
				$responce['project_id'] = $_POST['project_id'];
				//$responce['discipline_id'] = $_POST['discipline_id'];
				echo json_encode($responce);			
			}else{
				$responce['code']="1";
				$responce['msg']="<font color='red'>No Task Or Discipline Found !!!</font>";
				echo json_encode($responce);
			}		
	}

}
?>