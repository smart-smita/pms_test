<?php
require_once APPPATH . 'core/Base_Controller.php';
if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
#[\AllowDynamicProperties]
class Master extends Base_Controller {
	public function __construct() {
		parent::__construct ();
			if(!isset($_SESSION['employee_code']) || $_SESSION['employee_code'] == ""){
				  redirect(base_url("index.php/Welcome/index/your session has expired please re-login"));
			}
	}

	public function getEmployeesOnApiCall(){

	$curl = curl_init();
$url="http://htco-erp.ethdigitalcampus.com/WebAPI/service/DC/EmployeeDetails";
curl_setopt_array($curl, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_SSL_VERIFYPEER => false,
	        CURLOPT_CUSTOMREQUEST => "POST",
		    CURLOPT_POSTFIELDS => "school_code=HTCO",
            CURLOPT_HTTPHEADER => array(
                 "Content-Type: application/x-www-form-urlencoded"
                  ),
                ));

$result = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
 $response =  json_decode($result)->Employee_Details;
$flag="0";
		$data = $this->Base_Models->CustomeQuary ( "SELECT employee_code ,employee_discipline_data
				FROM htco_employee_master WHERE employee_id!=1 " );
			if (is_array($response)) {
				foreach($response as $key=>$val){
					$flag="0";
					$dis = null;
					if (is_array($data)) {
						foreach($data as $row){	
							if($val->employeeCode==$row['employee_code']){
								$flag = $row['employee_code'];
								$dis = $row['employee_discipline_data'];
								break;						
							}
						}
					}
					if($flag=="0"){
					$this->Base_Models->AddValues("htco_employee_master",
						 array(
							"employee_code"=>$val->employeeCode,
						"employee_email_id"=>$val->emailID,
						"employee_discipline_data"=>$val->Discipline,
						"employee_designation"=>$val->Designation,
						"employee_name"=>$val->employeeName
						 ) );
					if (is_array($data)) {
						array_push($data,array(
								"employee_code"=>$val->employeeCode,
							"employee_discipline_data"=>$val->Discipline
						 ));
					}

					}else{
					
					$dis_val = explode(',',$dis ?? '');
					$dis1 = $val->Discipline;
					foreach($dis_val as $val1){
						if($val1==$val->Discipline){
							$dis1 = 1;
						}
					}
					if($dis1!=1){
						$dis .= ",".$dis1;
					}
					$this->Base_Models->UpadateValue("htco_employee_master",
						array(
						"employee_code"=>$val->employeeCode,
						"employee_email_id"=>$val->emailID,
						"employee_discipline_data"=>$dis,
						"employee_designation"=>$val->Designation,
						"employee_name"=>$val->employeeName
						),
						array("employee_id"=>$flag));
					}
					
				}
			}
		}
		  redirect(base_url("index.php/Master/getEmployee"));
	}
	
	public function getEmployee() {
		$data ['display_contents'] = array (
				"id" => "ID",
				"employee_code" => "Code",
				"employee_name" => "Name",
				"employee_mobile" => "Mobile",
				"employee_email_id" => "Email ID",
				"status" => "Status"
				
		);
		$data ['table_data'] = $this->Base_Models->CustomeQuary ( "SELECT * 
				FROM htco_employee_master WHERE employee_status!=3" );
		$count = is_array($data ['table_data']) ? count($data ['table_data']) : 0;
		for($i = 0; $i < $count; $i ++) {
			$data ['table_data'] [$i] ['id'] = $i + 1;
			$data ['table_data'] [$i] ['status'] = '';
			if ($data ['table_data'] [$i] ['employee_status'] == 0 || $data ['table_data'] [$i] ['employee_status'] == 2) {
				$data ['table_data'] [$i] ['status'] = ($data ['table_data'] [$i] ['employee_status'] == 0) ? "Pending" : "Deactive";
			} else {
				$data ['table_data'] [$i] ['status'] = "Active";
			}
		}
		$url= base_url("index.php/Master/getEmployeesOnApiCall");
		$data1 ['title'] = "Employee Master";
		$data ['title'] = "<button class='btn btn-primary pull-right' style='margin-top: -45px;' onclick='window.location=\"".$url."\"'><i class='fa fa-retweet'></i></button>";
		$data1 ['content'] = $this->load->view ( "common/table-view", $data, true );
		$this->view ( "load_view", $data1 );
	}
		public function getDiscipline() {
		$data ['display_contents'] = array (
				"no" => "ID",
				"class_code" => "Code",
				"discipline_name" => "Name",
				"status" => "Status",
				"action" => "Action"
				
		);

		$data ['table_data'] = $this->Base_Models->CustomeQuary ( "SELECT * 
				FROM htco_discipline_master WHERE discipline_status!=3" );

		$count = is_array($data ['table_data']) ? count($data ['table_data']) : 0;
		for($i = 0; $i < $count; $i ++) {
			
			$data ['table_data'] [$i] ['status'] = '';
			$url = base_url("index.php/Master/addDiscipline/".$data ['table_data'] [$i] ['id']);
			$data ['table_data'] [$i] ['no'] = $i + 1;
			$data['table_data'][$i]['action'] = "<button class='btn btn-info' onclick='window.location=\"".$url."\"'><i class='fa fa-edit'></i></button>";
			if ($data ['table_data'] [$i] ['discipline_status'] == 0 || $data ['table_data'] [$i] ['discipline_status'] == 2) {
				$data ['table_data'] [$i] ['status'] = ($data ['table_data'] [$i] ['discipline_status'] == 0) ? "Pending" : "Deactive";
				$data['table_data'][$i]['action'] .= " 
							<button class='btn btn-warning ' 
								title='Activate Discipline'
								data-target = '#con-close-modal'
								form-data-url='" . base_url ( index_page().'Master/activeDiscipline/'.$data ['table_data'] [$i] ['id'] ) . "'
								modal-button-text='Activate'
								modal-title = 'Activate Discipline'
								modal-data = 'Are sure to Active Discipline?<input type=\"hidden\" name=\"status\" value=\"1\">'
								onclick='loadModal(this);'><i class='fa fa-unlock'></i></button> 
						";
						$data['table_data'][$i]['action'] .= "
							<button class='btn btn-warning ' 
								title='Remove Discipline'
								data-target = '#con-close-modal'
								form-data-url='" . base_url ( index_page().'Master/deleteDiscipline/'.$data ['table_data'] [$i] ['id'] ) . "'
								modal-button-text='Remove'
								modal-title = 'Remove Discipline'
								modal-data = 'Are sure to Remove Discipline?<input type=\"hidden\" name=\"status\" value=\"3\">'
								onclick='loadModal(this);'><i class='fa fa-trash'></i></button> 
						";

				} else {
				$data ['table_data'] [$i] ['status'] = "Active";
					$data['table_data'][$i]['action'] .= "
							<button class='btn btn-warning ' 
								title='Deactive Discipline'
								data-target = '#con-close-modal'
								form-data-url='" . base_url ( index_page().'Master/deactiveDiscipline/'.$data ['table_data'] [$i] ['id'] ) . "'
								modal-button-text='Deactive'
								modal-title = 'Deactive Discipline'
								modal-data = 'Are sure to Deactive Discipline?<input type=\"hidden\" name=\"status\" value=\"1\">'
								onclick='loadModal(this);'><i class='fa fa-close'></i></button> 
						";
			}

		}
		$url = base_url(index_page()."/Master/addDiscipline/");
		$data ['title'] = "<button class='btn btn-primary pull-right' style='margin-top: -45px;' onclick='window.location=\"".$url."\"'><i class='fa fa-plus'></i></button>";
		
		$data1 ['title'] = "Discipline Master ";
		$data1 ['content'] = $this->load->view ( "common/table-view", $data, true );
		$this->view ( "load_view", $data1 );
	}
function activeDiscipline($id){

				$temp = $this->Base_Models->UpadateValue("htco_discipline_master",array("discipline_status"=>1),array("id"=>$id));

		$respnse['load']=array(
								"events" => array(
									($_POST['status']==3?"row_hide":"button_hide")
								),
								"id" => array(
									0
								),
								"data" => array(
									($_POST['status']==5?"":($_POST['status']==1?"<button class='btn btn-warning ' 
								title='Deactivate Discipline'
								data-target = '#con-close-modal'
								form-data-url='" . base_url ( index_page().'Master/activeDiscipline/'.$id ) . "'
								modal-button-text='Deactivate'
								modal-title = 'Deactivate Discipline'
								modal-data = 'Are sure to Deactive Discipline?<input type=\"hidden\" name=\"status\" value=\"1\">'
								onclick='loadModal(this);'><i class='fa fa-close'></i></button>":""))
								)
						);
$respnse['message']="done";


echo json_encode($respnse);
}
function deactiveDiscipline($id){
	$temp = $this->Base_Models->UpadateValue("htco_discipline_master",array("discipline_status"=>2),array("id"=>$id));

	$respnse['load']=array(
								"events" => array(
									($_POST['status']==3?"row_hide":"button_hide")
								),
								"id" => array(
									0
								),
								"data" => array(
									($_POST['status']==3?"":($_POST['status']==1?"<button class='btn btn-warning ' 
								title='Activate Discipline'
								data-target = '#con-close-modal'
								form-data-url='" . base_url ( index_page().'Master/activeDiscipline/'.$id ) . "'
								modal-button-text='Activate'
								modal-title = 'Activate Discipline'
								modal-data = 'Are sure to Active Discipline?<input type=\"hidden\" name=\"status\" value=\"1\">'
								onclick='loadModal(this);'><i class='fa fa-unlock'></i></button>":""))
								)
						);

$respnse['message']="done";
echo json_encode($respnse);
}
function deleteDiscipline($id){
	$temp = $this->Base_Models->UpadateValue("htco_discipline_master",array("discipline_status"=>3),array("id"=>$id));
	$respnse['load']=array(
								"events" => array(
									"row_hide"
								),
								"id" => array(
									0
								),
								"data" => array()
						);

$respnse['message']="done";
echo json_encode($respnse);
}


	function addDiscipline($id=null){
		
		$data=null;
		$data['action'] = base_url("index.php/Master/acceptDiscipline");
		$data['title'] = "Add Discipline";
		if(isset($id)){
			$temp = $this->Base_Models->GetAllValues("htco_discipline_master", array('id' =>$id));
			if(is_array($temp) && count($temp)>0){
				$data=$temp[0];
					$data['action'] = base_url("index.php/Master/acceptDiscipline/".$id);
					$data['title'] = "Edit Discipline";
				}
		}
		$this->view("forms/discipline_form",$data);
		
	}
	function acceptDiscipline($id=null){
		$url="";
		if(isset($id)){
			$this->Base_Models->UpadateValue("htco_discipline_master",$_POST,array("id"=>$id));
			$url = base_url("index.php/Master/addDiscipline/".$id);
		}else{			
			$this->Base_Models->AddValues("htco_discipline_master",$_POST);
			$url = base_url("index.php/Master/addDiscipline/");
		}
		redirect($url);

	}
	public function profile($id = null) {
		$data = array ();
		if (!isset ( $id )) {
			//$id= $_SE
			if(isset($_SESSION['employee_code']))
			$id = $_SESSION['employee_code'];
			else{
				  redirect(base_url("index.php/Welcome/index/your session has expired please re-login"));
			}
		}

			$temp = $this->Base_Models->GetAllValues ( "htco_employee_master", array (
					"employee_code" =>  $id
			) );
			
			$data = $temp[0];
			$data ['action_url'] = base_url ( '/index.php/Master/acceptEmployee' . (isset ( $id ) ? "/" . $id : "") );
		$data ['title'] = "Employee Profile";
		$data ['task_list'] = $this->Base_Models->GetAllValues ( "htco_discipline_master" );
		$this->view ( "employee_form", $data );
	}
}
?>