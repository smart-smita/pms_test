<?php
if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
#[\AllowDynamicProperties]
class jsganttchartmodel extends CI_Model {
	function __construct() {
		/* Call the Model constructor */
		parent::__construct ();
		$this->load->helper ( 'array' );
	}
	function getIndexedArray($key, $val, $parent = 0) {
		$ChartValues ['id'] = $key;
		$ChartValues ['title'] = isset ( $val ['title'] ) ? $val ['title'] : "";
		$ChartValues ['start_date'] = isset ( $val ['start_date'] ) ? $val ['start_date'] : "";
		$ChartValues ['end_date'] = isset ( $val ['end_date'] ) ? $val ['end_date'] : "";
		if (isset ( $val ['is_milestone'] ) && $val ['is_milestone'] == 1) {
			$ChartValues ['class'] = "gmilestone";
		}
		if (isset ( $val ['is_group'] ) && ($val ['is_group'] == 1 || $val ['is_group'] == 2)) {
			$ChartValues ['class'] = "ggroupblack";
		} else {
			$ChartValues ['class'] = "gtaskblue";
			if (isset ( $val ['percentage'] ) && $val ['percentage'] == 100) {
				$ChartValues ['class'] = "gtaskgreen";
			}
		}
		$ChartValues ['link'] = isset ( $val ['link'] ) ? $val ['link'] : "";
		$ChartValues ['is_milestone'] = isset ( $val ['is_milestone'] ) ? $val ['is_milestone'] : "0";
		$ChartValues ['resource_name'] = isset ( $val ['resource_name'] ) ? $val ['resource_name'] : "";
		$ChartValues ['percentage'] = isset ( $val ['percentage'] ) && $val ['percentage'] > 0 ? $val ['percentage'] : 0;
		$ChartValues ['is_group'] = isset ( $val ['is_group'] ) ? $val ['is_group'] : 0;
		$ChartValues ['parent_id'] = $parent;
		$ChartValues ['open'] = isset ( $val ['open'] ) ? $val ['open'] : 1;
		$ChartValues ['dependency'] = isset ( $val ['dependency'] ) ? $val ['dependency'] : "";
		$ChartValues ['caption'] = isset ( $val ['caption'] ) ? $val ['caption'] : "";
		$ChartValues ['note'] = isset ( $val ['note'] ) ? $val ['note'] : "";
		return $ChartValues;
	}
	/**
	 *
	 * @param array $ChartValues
	 *        	contains
	 *        	<br><b>title</b>
	 *        	<br><b>start_date</b>
	 *        	<br><b>end_date</b>
	 *        	<br> <b>class</b> names like g__color_name
	 *        	<br>ex. gtaskred,ggroupblack,gmilestone,gtaskpink, gtaskblue, gtaskyellow, gtaskpurple,gtaskgreen,gtaskpurple
	 *        	<br><b>link</b> optional
	 *        	<br><b>is_milestone</b> optional
	 *        	<br><b>resource_name</b> optional
	 *        	<br><b>percentage</b>
	 *        	<br><b>is_group</b>
	 *        	<br><b>open</b> optional
	 *        	<br><b>dependency</b> optional
	 *        	<br><b>caption</b> optional
	 *        	<br><b>note</b> optional
	 *        	<br><b>data</b> contains child array with same structure
	 * @example $ChartValues ['table_data'] = array (
	 *          111 => array (
	 *          "title" => "Define Chart API", "start_date" => "2016-02-11",
	 *          "end_date" => "", "class" => "ggroupblack",
	 *          "link" => "", "is_milestone" => "0",
	 *          "resource_name" => "Brian", "percentage" => "0",
	 *          "is_group" => 1, "open" => 1, "dependency" => "",
	 *          "caption" => "", "note" => "Some Notes text",
	 *          "data" => array (
	 *          112 => array ( "title" => "Chart Object",
	 *          "start_date" => "2016-02-20", "end_date" => "2016-02-21",
	 *          "class" => "gmilestone", "link" => "",
	 *          "is_milestone" => "1", "resource_name" => "Shlomy",
	 *          "percentage" => "100", "dependency" => "",
	 *          "caption" => "", "note" => ""
	 *          ),
	 *          113 => array (
	 *          "title" => "Task Objects", "start_date" => "2016-02-25",
	 *          "end_date" => "2016-03-10", "class" => "ggroupblack",
	 *          "link" => "", "is_milestone" => "0",
	 *          "resource_name" => "Shlomy", "percentage" => "40",
	 *          "is_group" => 2, "dependency" => "", "caption" => "", "note" => "",
	 *          "data" => array ( 114 => array (
	 *          "title" => "Chart Object", "start_date" => "2016-02-20",
	 *          "end_date" => "2016-02-21", "class" => "gtaskred",
	 *          "link" => "", "is_milestone" => "0",
	 *          "resource_name" => "Shlomy", "percentage" => "10",
	 *          "dependency" => "", "caption" => "",
	 *          "note" => "" ), 115 => array ( "title" => "Chart Object",
	 *          "start_date" => "2016-02-25","end_date" => "2016-02-26",
	 *          "class" => "gtaskred", "link" => "",
	 *          "is_milestone" => "0", "resource_name" => "Shlomy",
	 *          "percentage" => "20", "dependency" => "114",
	 *          "caption" => "","note" => ""))))) );
	 *         
	 */
	function defaultChart($ChartValues = array()) {
		$i = 0;
		$Values = $ChartValues;
		unset ( $ChartValues );
		$ChartValues = null;
		foreach ( $Values ['table_data'] as $key => $val ) {
			$ChartValues ['table_data'] [$i ++] = $this->getIndexedArray ( $key, $val );
			if (isset ( $val ['data'] ) && is_array ( $val ['data'] )) {
				foreach ( $val ['data'] as $key1 => $val1 ) {
					$ChartValues ['table_data'] [$i ++] = $this->getIndexedArray ( $key1, $val1, $key );
					if (isset ( $val1 ['data'] ) && is_array ( $val1 ['data'] )) {
						foreach ( $val1 ['data'] as $key2 => $val2 ) {
							$ChartValues ['table_data'] [$i ++] = $this->getIndexedArray ( $key2, $val2, $key1 );
							if (isset ( $val2 ['data'] ) && is_array ( $val2 ['data'] )) {
								foreach ( $val2 ['data'] as $key3 => $val3 ) {
									$ChartValues ['table_data'] [$i ++] = $this->getIndexedArray ( $key3, $val3, $key2 );
								}
							}
						}
					}
				}
			}
		}
		return $this->load->view ( 'common/jsgantt/js_gantt_view', $ChartValues, true );
	}
}
?>