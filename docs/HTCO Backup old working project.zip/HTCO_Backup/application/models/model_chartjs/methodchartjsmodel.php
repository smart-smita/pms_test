<?php
require_once APPPATH . 'models/model_chartjs/baseChartjsModel.php';
if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
#[\AllowDynamicProperties]
class methodchartjsmodel extends baseChartjsModel {
	function __construct() {
		/* Call the Model constructor */
		parent::__construct ();
	}
	
	// --------------------------------------------------------------------------------------------
	// ---------------------------------------- BAR CHART METHODS ---------------------------------
	// --------------------------------------------------------------------------------------------
	/**
	 *
	 * @param String $chartTitle        	
	 * @param Array $chartValues
	 *        	2D Array With Fields as in format:
	 *        	<br>title > Title on Chart
	 *        	<br>values > array with <b>label & value</b> pair
	 *        	<br>fill_background > optional
	 *        	<br>background_color > optional
	 *        	<br>interpolation > optional formatting
	 *        	<br>
	 * @example $arr [1] ['title'] = "Title On Chart";
	 *          <br>$arr [1] ['fill_background'] = true;
	 *          <br>$arr [1] ['background_color'] = "Yellow";
	 *          <br>$arr [1] ['interpolation'] = "linear";
	 *          <br>$arr [1] ['values'] = array ( <br>array (
	 *          <br>"label" => "Red",
	 *          <br>"value" => "25"
	 *          <br>));
	 * @param String $x_label        	
	 * @param String $y_label        	
	 * @param bool $beginatzero        	
	 */
	function basicBarChart($chartTitle, $chartValues, $x_label, $y_label, $beginatzero = false, $operation = '') {
		return $this->defaultChart ( "bar", $chartTitle, $chartValues, $x_label, $y_label, $beginatzero, $operation );
	}
	function horizontalBarChart($chartTitle, $chartValues, $x_label, $y_label, $beginatzero = false, $operation = "") {
		return $this->defaultChart ( "horizontalBar", $chartTitle, $chartValues, $x_label, $y_label, $beginatzero, $operation );
	}
	function stackedBarChart($chartTitle, $chartValues, $x_label, $y_label, $beginatzero, $operation = '') {
		return $this->defaultChart ( "stackedBar", $chartTitle, $chartValues, $x_label, $y_label, $beginatzero, $operation );
	}
	function stackedHorizontalBarChart($chartTitle, $chartValues, $x_label, $y_label, $beginatzero, $operation = "") {
		return $this->defaultChart ( "horizontalStackedBar", $chartTitle, $chartValues, $x_label, $y_label, $beginatzero, $operation );
	}
	function stackedGroupBarChart($chartTitle, $chartValues, $x_label, $y_label, $beginatzero, $operation = '') {
		return $this->defaultChart ( "groupStackedBar", $chartTitle, $chartValues, $x_label, $y_label, $beginatzero, $operation );
	}
	function horizontalGroupStackedBarChart($chartTitle, $chartValues, $x_label, $y_label, $beginatzero, $operation = '') {
		return $this->defaultChart ( "horizontalGroupStackedBar", $chartTitle, $chartValues, $x_label, $y_label, $beginatzero, $operation );
	}
	
	// --------------------------------------------------------------------------------------------
	// -------------------------------- LINE CHART METHODS ----------------------------------------
	// --------------------------------------------------------------------------------------------
	function basicLineChart($chartTitle, $chartValues, $x_label, $y_label, $beginatzero = false, $operation = '') {
		return $this->defaultChart ( "line", $chartTitle, $chartValues, $x_label, $y_label, $beginatzero, $operation );
	}
	function dottedLineChart($chartTitle, $chartValues, $x_label, $y_label, $beginatzero, $operation = '') {
		return $this->defaultChart ( "dottedLine", $chartTitle, $chartValues, $x_label, $y_label, $beginatzero, $operation );
	}
	function steppedDefaultLineChart($chartTitle, $chartValues, $x_label, $y_label, $beginatzero, $operation = '') {
		return $this->defaultChart ( "steppedLine", $chartTitle, $chartValues, $x_label, $y_label, $beginatzero, $operation );
	}
	function steppedBeforeLineChart($chartTitle, $chartValues, $x_label, $y_label, $beginatzero, $operation = '') {
		return $this->defaultChart ( "steppedLineBefore", $chartTitle, $chartValues, $x_label, $y_label, $beginatzero, $operation );
	}
	function steppedAfterLineChart($chartTitle, $chartValues, $x_label, $y_label, $beginatzero, $operation = '') {
		return $this->defaultChart ( "steppedLineAfter", $chartTitle, $chartValues, $x_label, $y_label, $beginatzero, $operation );
	}
	/**
	 *
	 * @param String $chartTitle        	
	 * @param Array $chartValues
	 *        	2D Array With Fields as in format:
	 *        	<br>title > Title on Chart
	 *        	<br>values > array with <b>label & value</b> pair
	 *        	<br>fill_background > optional
	 *        	<br>background_color > optional
	 *        	<br>interpolation > optional formatting
	 *        	<br>
	 * @example $arr [1] ['title'] = "Title On Chart";
	 *          <br>$arr [1] ['fill_background'] = true;
	 *          <br>$arr [1] ['background_color'] = "Yellow";
	 *          <br>$arr [1] ['interpolation'] = "linear";
	 *          <br>$arr [1] ['values'] = array ( <br>array (
	 *          <br>"label" => "Red",
	 *          <br>"value" => "25"
	 *          <br>));
	 * @param String $x_label        	
	 * @param String $y_label        	
	 * @param bool $beginatzero        	
	 */
	function cubicInterpolationLineChart($chartTitle, $chartValues, $x_label, $y_label, $beginatzero, $operation = '') {
		foreach ( $chartValues as $key => $val ) {
			$chartValues [$key] ['interpolation'] = false;
			if (isset ( $val ['interpolation'] ))
				if ($val ['interpolation'] == 'monotone') {
					$chartValues [$key] ['interpolation'] = 'monotone';
				} elseif ($val ['interpolation'] == 'linear') {
					$chartValues [$key] ['interpolation'] = 'linear';
				}
			foreach ( $val ['values'] as $key1 => $val1 ) {
				$chartValues [$key] [$key1] ['label'] = $val1 ['label'];
				$chartValues [$key] [$key1] ['value'] = isset ( $val1 ['value'] ) ? $val1 ['value'] : '';
			}
		}
		return $this->defaultChart ( "cubicInterpolationLine", $chartTitle, $chartValues, $x_label, $y_label, $beginatzero, $operation );
	}
	
	// --------------------------------------------------------------------------------------------
	// ---------------------------------------- RADAR CHART METHODS ---------------------------------
	// --------------------------------------------------------------------------------------------
	function basicRadarChart($chartTitle, $chartValues, $xLabel = "", $yLabel = "", $start_at_zero = false, $operation = '') {
		return $this->defaultChart ( "radar", $chartTitle, $chartValues, $xLabel, $yLabel, $start_at_zero, $operation );
	}
	
	// --------------------------------------------------------------------------------------------
	// ---------------------------------------- SCATTER CHART METHODS ---------------------------------
	// --------------------------------------------------------------------------------------------
	function basicScatterChart($chartTitle, $chartValues, $xLabel, $yLabel, $start_at_zero = false, $operation = '') {
		return $this->defaultChart ( "scatter", $chartTitle, $chartValues, $xLabel, $yLabel, $start_at_zero, $operation );
	}
	
	// --------------------------------------------------------------------------------------------
	// ---------------------------------------- DOUGHNUT CHART METHODS ---------------------------------
	// --------------------------------------------------------------------------------------------
	function basicDoughnutChart($chartTitle, $chartValues, $xLabel = "", $yLabel = "", $start_at_zero = false, $operation = '') {
		return $this->defaultChart ( "doughnut", $chartTitle, $chartValues, $xLabel, $yLabel, $start_at_zero, $operation );
	}
	
	// --------------------------------------------------------------------------------------------
	// ---------------------------------------- PIE CHART METHODS ---------------------------------
	// --------------------------------------------------------------------------------------------
	function basicPieChart($chartTitle, $chartValues, $xLabel = "", $yLabel = "", $start_at_zero = false, $operation = '') {
		return $this->defaultChart ( "pie", $chartTitle, $chartValues, $xLabel, $yLabel, $start_at_zero, $operation );
	}
	
	// --------------------------------------------------------------------------------------------
	// ---------------------------------------- PIE CHART METHODS ---------------------------------
	// --------------------------------------------------------------------------------------------
	function basicPolarChart($chartTitle, $chartValues, $xLabel = "", $yLabel = "", $start_at_zero = false, $operation = '') {
		return $this->defaultChart ( "polarArea", $chartTitle, $chartValues, $xLabel, $yLabel, $start_at_zero, $operation );
	}
	
	// --------------------------------------------------------------------------------------------
	// ---------------------------------------- COMBINE LINE AND BAR CHART METHODS ---------------------------------
	// --------------------------------------------------------------------------------------------
	function combineLineBarChart($chartTitle, $chartValues, $xLabel, $yLabel, $start_at_zero = false, $operation = '') {
		return $this->defaultChart ( "combineLineBar", $chartTitle, $chartValues, $xLabel, $yLabel, $start_at_zero, $operation );
	}
	
	// --------------------------------------------------------------------------------------------
	// ---------------------------------------- COMBINE STACKED LINE AND BAR CHART METHODS ---------------------------------
	// --------------------------------------------------------------------------------------------
	function combineStackedLineBarChart($chartTitle, $chartValues, $xLabel, $yLabel, $start_at_zero = false, $operation = '') {
		return $this->defaultChart ( "combineStackedLineBar", $chartTitle, $chartValues, $xLabel, $yLabel, $start_at_zero, $operation );
	}
}
?>